package cn.edu.hit.backend;

import cn.edu.hit.backend.util.jwt.JWTUtil;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndApplicationTests {

    @Test
    void contextLoads() {
    }

    @Test
    void jwtMakeAndCheck() throws InterruptedException {
        String token = JWTUtil.makeJWS("teacher", 60);
        assert JWTUtil.CheckResult.OK == JWTUtil.checkJWS(token, "teacher");
        assert JWTUtil.CheckResult.UNAUTHORIZED == JWTUtil.checkJWS(token, "admin");

        StringBuilder sb = new StringBuilder(token);
        sb.setCharAt(0, '?');
        String badToken = sb.toString();
        assert JWTUtil.CheckResult.INVALID == JWTUtil.checkJWS(badToken, "teacher");

        token = JWTUtil.makeJWS("admin", 5);
        Thread.sleep(10 * 1000);
        assert JWTUtil.CheckResult.EXPIRED == JWTUtil.checkJWS(token, "admin");
        assert JWTUtil.CheckResult.EXPIRED == JWTUtil.checkJWS(token, "teacher");
    }

}
