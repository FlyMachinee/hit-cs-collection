package cn.edu.hit.backend.mapper;

import cn.edu.hit.backend.entity.user.Admin;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface AdminMapper {
    @Select("select * from admin where id=#{id} and password=#{password}")
    Admin login(String id, String password);

    @Select("select * from admin where id=#{id}")
    Admin getAdminById(String id);

    @Update("update admin set email = #{email}, password = #{password} where id = #{id}")
    void updateInfo(String id, String email, String password);
}
