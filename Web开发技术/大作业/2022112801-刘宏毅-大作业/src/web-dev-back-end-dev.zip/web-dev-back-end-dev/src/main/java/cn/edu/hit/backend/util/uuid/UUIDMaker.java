package cn.edu.hit.backend.util.uuid;

public class UUIDMaker {
    public static String getUUID() {
        return java.util.UUID.randomUUID().toString().replace("-", "");
    }
}
