package cn.edu.hit.backend.service;

import cn.edu.hit.backend.controller.TeacherController;
import cn.edu.hit.backend.util.result.Result;

public interface TeacherService {
    Result login(String id, String password);
    Result getTeacherList();
    Result getTeacherById(String id);
    Result createTeacher(TeacherController.TeacherNoPassword teacher);
    Result updateTeacher(String oldId, TeacherController.TeacherNoPassword teacher);
    Result updateTeacherInfo(String id, String email, String password);
    Result deleteTeacherById(String id);
}
