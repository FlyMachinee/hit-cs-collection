package cn.edu.hit.backend.entity.user;

import java.util.Set;

import cn.edu.hit.backend.entity.course.CourseOffering;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
public class Teacher extends User {
    private String faculty;
    private String title;

    public Teacher(String id, String name, String password, String email, String gender, String faculty, String title) {
        super(id, name, password, email, gender);
        this.faculty = faculty;
        this.title = title;
    }
}
