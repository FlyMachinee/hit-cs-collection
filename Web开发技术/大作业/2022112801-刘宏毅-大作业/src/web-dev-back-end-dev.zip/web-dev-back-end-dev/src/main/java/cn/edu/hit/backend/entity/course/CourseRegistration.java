package cn.edu.hit.backend.entity.course;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CourseRegistration {
    private String id;
    private String studentId;
    private String offeringId;
    private Double score;
}
