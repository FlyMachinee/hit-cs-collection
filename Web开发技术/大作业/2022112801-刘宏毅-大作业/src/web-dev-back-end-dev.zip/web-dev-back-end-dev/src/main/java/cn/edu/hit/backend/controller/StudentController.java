package cn.edu.hit.backend.controller;

import cn.edu.hit.backend.service.StudentService;
import cn.edu.hit.backend.util.result.Result;
import cn.edu.hit.backend.entity.user.User;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/student")
@CrossOrigin
public class StudentController {
    @Autowired
    private StudentService studentService;

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class StudentNoPassword {
        private String id;
        private String name;
        private String gender;
        private String email;
        private String major;
        private String faculty;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class StudentData extends StudentNoPassword {
        private int index;
    }

    @GetMapping("/all")
    public Result getStudentList() {
        return studentService.getStudentList();
    }

    @GetMapping
    public Result getStudentById(@RequestParam(required = true, name = "id") String id) {
        return studentService.getStudentById(id);
    }

    @PostMapping
    public Result createStudent(@RequestBody StudentNoPassword student) {
        return studentService.createStudent(student);
    }

    @PutMapping
    public Result updateStudent(@RequestParam(required = true, value = "oldId") String oldId, @RequestBody StudentNoPassword student) {
        return studentService.updateStudent(oldId, student);
    }

    @PutMapping("/info")
    public Result updateStudentInfo(@RequestBody User user) {
        return studentService.updateStudentInfo(user.getId(), user.getEmail(), user.getPassword());
    }

    @DeleteMapping
    public Result deleteStudentById(@RequestParam(required = true, value = "id") String id) {
        return studentService.deleteStudentById(id);
    }
}
