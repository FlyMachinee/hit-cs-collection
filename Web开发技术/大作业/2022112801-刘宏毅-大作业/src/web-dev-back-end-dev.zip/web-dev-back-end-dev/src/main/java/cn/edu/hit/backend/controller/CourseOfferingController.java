package cn.edu.hit.backend.controller;

import cn.edu.hit.backend.service.CourseOfferingService;
import cn.edu.hit.backend.util.result.Result;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/courseOffering")
@CrossOrigin
public class CourseOfferingController {
    @Autowired
    private CourseOfferingService courseOfferingService;

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class CourseOfferingData {
        private Integer index;
        private String id;
        private String courseName;
        private String teacherName;
        private String place;
        private String semester;
        private String startWeek;
        private String endWeek;
        private String startPeriod;
        private String endPeriod;
    }

    @GetMapping("/all")
    public Result getOfferingList() {
        return courseOfferingService.getOfferingList();
    }

    @GetMapping
    public Result getOfferingById(@RequestParam(required = true, name = "id") String id) {
        return courseOfferingService.getOfferingById(id);
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class CourseOfferingWithoutId {
        private String courseId;
        private String teacherId;
        private String place;
        private String semester;
        private Integer startWeek;
        private Integer endWeek;
        private Integer startPeriod;
        private Integer endPeriod;
    }

    @PostMapping
    public Result createOffering(@RequestBody CourseOfferingWithoutId courseOfferingWithoutId) {
        return courseOfferingService.createOffering(courseOfferingWithoutId);
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class CourseOfferingAlterable {
        private String id;
        private String place;
        private String semester;
        private Integer startWeek;
        private Integer endWeek;
        private Integer startPeriod;
        private Integer endPeriod;
    }

    @PutMapping
    public Result updateOffering(@RequestBody CourseOfferingAlterable courseOfferingAlterable) {
        return courseOfferingService.updateOffering(courseOfferingAlterable);
    }

    @DeleteMapping
    public Result deleteOffering(@RequestParam(required = true, name = "id") String id) {
        return courseOfferingService.deleteOffering(id);
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Data {
        private String id;
        private String code;
        private String name;
        private String info;
        private String faculty;
        private Double credits;
        private Double hours;
    }

    @GetMapping("/optional")
    public Result getOptionalOfferingList(@RequestParam(required = true, name = "semester") String semester,
                                          @RequestParam(required = true, name = "studentId") String studentId) {
        return courseOfferingService.getOptionalOfferingList(semester, studentId);
    }

    @GetMapping("/selected")
    public Result getSelectedOfferingList(@RequestParam(required = true, name = "semester") String semester,
                                          @RequestParam(required = true, name = "studentId") String studentId) {
        return courseOfferingService.getSelectedOfferingList(semester, studentId);
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class TeacherOffering {
        private String id;
        private String code;
        private String name;
        private float credits;
        private int hours;
    }

    @GetMapping("/teacher")
    public Result getOfferingListByTeacher(@RequestParam(required = true, name = "semester") String semester,
                                          @RequestParam(required = true, name = "teacherId") String teacherId) {
        return courseOfferingService.getOfferingListByTeacher(semester, teacherId);
    }
}
