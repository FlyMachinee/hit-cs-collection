package cn.edu.hit.backend.mapper;

import cn.edu.hit.backend.controller.CourseOfferingController;
import cn.edu.hit.backend.controller.CourseRegistrationController;
import cn.edu.hit.backend.entity.course.CourseRegistration;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CourseRegistrationMapper {

    @Insert("insert into course_registration(id, student_id, offering_id, score) values (#{id}, #{studentId}, #{offeringId}, #{score})")
    void createCourseRegistration(CourseRegistration courseRegistration);

    @Delete("delete from course_registration where student_id = #{studentId} and offering_id = #{offeringId}")
    void deleteCourseRegistration(String studentId, String offeringId);

    @Select("select " +
            "course_registration.id as id, " +
            "course_offering.course_id as code, " +
            "(select name from course where course.id = course_offering.course_id) as name, " +
            "(select faculty from teacher where teacher.id = course_offering.teacher_id) as faculty, " +
            "(select credits from course where course.id = course_offering.course_id) as credits, " +
            "course_registration.score as score, " +
            "((select credits from course where course.id = course_offering.course_id) * course_registration.score) as gradePoint " +
            "from course_registration, course_offering " +
            "where offering_id = course_offering.id and " +
            "   student_id = #{studentId}")
    List<CourseRegistrationController.Data> getScoreForStudent(String studentId);

    @Select("select " +
            "course_registration.id as id, " +
            "course_registration.student_id as studentId, " +
            "student.name as studentName, " +
            "student.email as studentEmail, " +
            "student.faculty as faculty, " +
            "course_registration.score as score " +
            "from course_registration, student " +
            "where course_registration.student_id = student.id and " +
            "offering_id = #{offeringId}")
    List<CourseRegistrationController.ScoreForTeacher> getScoreForTeacher(String offeringId);

    @Select("select " +
            "row_number() over (order by student_id) as index, " +
            "course_registration.student_id as studentId, " +
            "student.name as studentName, " +
            "student.email as studentEmail, " +
            "student.faculty as faculty, " +
            "course_registration.score as score " +
            "from course_registration, student " +
            "where course_registration.student_id = student.id and " +
            "offering_id = #{offeringId}")
    List<CourseRegistrationController.ScoreForAdmin> getScoreForAdmin(String offeringId);

    @Update("update course_registration set score = #{score} where id = #{id}")
    void registrationScore(String id, Double score);
}
