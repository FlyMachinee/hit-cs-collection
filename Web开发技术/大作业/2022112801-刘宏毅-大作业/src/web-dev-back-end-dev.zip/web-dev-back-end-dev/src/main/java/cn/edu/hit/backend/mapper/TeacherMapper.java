package cn.edu.hit.backend.mapper;

import java.util.List;

import cn.edu.hit.backend.controller.TeacherController;
import org.apache.ibatis.annotations.*;

import cn.edu.hit.backend.entity.user.Teacher;

@Mapper
public interface TeacherMapper {
    @Select("select * from teacher where id=#{id} and password=#{password}")
    Teacher login(String id, String password);


    @Select("select row_number() over (order by id) as index, * from teacher")
    List<TeacherController.TeacherData> findAll();

    @Select("select * from teacher where id = #{id}")
    Teacher findById(String id);

    @Delete("delete from teacher where id = #{id}")
    void delete(String id);

    @Insert("insert into teacher(id, name, gender, email, title, faculty, password) values(#{id}, #{name}, #{gender}, #{email}, #{title}, #{faculty}, 'hit520')")
    void add(TeacherController.TeacherNoPassword teacher);

    @Update("update teacher set id = #{teacher.id}, name = #{teacher.name}, gender = #{teacher.gender}, email = #{teacher.email}, title = #{teacher.title} where id = #{oldId}")
    void update(String oldId, TeacherController.TeacherNoPassword teacher);

    @Update("update teacher set email = #{email}, password = #{password} where id = #{id}")
    void updateInfo(String id, String email, String password);
}
