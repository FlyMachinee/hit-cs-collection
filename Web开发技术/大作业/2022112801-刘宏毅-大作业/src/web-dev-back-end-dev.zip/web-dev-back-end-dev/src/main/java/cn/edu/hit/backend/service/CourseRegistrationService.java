package cn.edu.hit.backend.service;

import cn.edu.hit.backend.controller.CourseRegistrationController;
import cn.edu.hit.backend.util.result.Result;

public interface CourseRegistrationService {
    Result registerCourse(String studentId, String offeringId);
    Result withdrawCourse(String studentId, String offeringId);
    Result getScoreForStudent(String studentId);
    Result getScoreForTeacher(String offeringId);
    Result getScoreForAdmin(String offeringId);
    Result registerScore(CourseRegistrationController.ScoreForTeacher[] registrationList);
}
