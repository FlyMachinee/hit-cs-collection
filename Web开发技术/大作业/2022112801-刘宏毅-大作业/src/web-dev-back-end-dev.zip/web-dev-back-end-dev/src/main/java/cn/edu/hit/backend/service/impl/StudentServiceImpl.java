package cn.edu.hit.backend.service.impl;

import cn.edu.hit.backend.controller.LoginController;
import cn.edu.hit.backend.controller.StudentController;
import cn.edu.hit.backend.entity.user.Student;
import cn.edu.hit.backend.mapper.StudentMapper;
import cn.edu.hit.backend.service.StudentService;
import cn.edu.hit.backend.util.jwt.JWTUtil;
import cn.edu.hit.backend.util.result.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentMapper studentMapper;

    @Override
    public Result login(String id, String password) {
        Student student = studentMapper.login(id, password);
        if (student == null) {
            return new Result(406, "用户名或密码错误！", null);
        } else {
            String token = JWTUtil.makeJWS("student", 60 * 60);
            return new Result(new LoginController.LoginOutputData(token, studentMapper.findById(id)));
        }
    }

    @Override
    public Result getStudentList() {
        try {
            return new Result(studentMapper.findAll());
        } catch (Exception e) {
            return new Result(400, "查询学生失败", null);
        }
    }

    @Override
    public Result getStudentById(String id) {
        try {
            return new Result(studentMapper.findById(id));
        } catch (Exception e) {
            return new Result(400, "查询学生失败", null);
        }
    }

    @Override
    public Result createStudent(StudentController.StudentNoPassword student) {
        try {
            studentMapper.add(student);
        } catch (Exception e) {
            return new Result(400, "添加学生失败", null);
        }
        return new Result(null);
    }

    @Override
    public Result updateStudent(String oldId, StudentController.StudentNoPassword student) {
        try {
            studentMapper.update(oldId, student);
        } catch (Exception e) {
            return new Result(400, "修改学生失败", null);
        }
        return new Result(null);
    }

    @Override
    public Result updateStudentInfo(String id, String email, String password) {
        try {
            studentMapper.updateInfo(id, email, password);
        } catch (Exception e) {
            return new Result(400, "修改学生信息失败", null);
        }
        return new Result(null);
    }

    @Override
    public Result deleteStudentById(String id) {
        try {
            studentMapper.delete(id);
        } catch (Exception e) {
            return new Result(400, "删除学生失败", null);
        }
        return new Result(null);
    }

}
