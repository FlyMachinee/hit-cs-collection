package cn.edu.hit.backend.controller;

import cn.edu.hit.backend.service.AdminService;
import cn.edu.hit.backend.service.StudentService;
import cn.edu.hit.backend.service.TeacherService;
import cn.edu.hit.backend.util.result.Result;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/login")
@CrossOrigin
public class LoginController {

    @Autowired
    AdminService adminService;

    @Autowired
    StudentService studentService;

    @Autowired
    TeacherService teacherService;

    @PostMapping
    public Result login(@RequestBody LoginInputData loginInputData) {
        return switch (loginInputData.getRole()) {
            case "admin" -> adminService.login(loginInputData.getUsername(), loginInputData.getPassword());
            case "student" -> studentService.login(loginInputData.getUsername(), loginInputData.getPassword());
            case "teacher" -> teacherService.login(loginInputData.getUsername(), loginInputData.getPassword());
            default -> new Result(400, "角色错误", null);
        };
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class LoginInputData {
        private String username;
        private String password;
        private String role;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class LoginOutputData {
        private String token;
        private Object userData;
    }

}
