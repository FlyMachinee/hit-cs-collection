package cn.edu.hit.backend.controller;

import cn.edu.hit.backend.entity.user.User;
import cn.edu.hit.backend.service.TeacherService;
import cn.edu.hit.backend.util.result.Result;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("teacher")
@CrossOrigin
public class TeacherController {

    @Autowired
    private TeacherService teacherService;

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class TeacherNoPassword {
        private String id;
        private String name;
        private String gender;
        private String email;
        private String title;
        private String faculty;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class TeacherData extends TeacherNoPassword {
        private int index;
    }

    @GetMapping("/all")
    public Result getTeacherList() {
        return teacherService.getTeacherList();
    }

    @GetMapping
    public Result getTeacherById(@RequestParam(required = true, name = "id") String id) {
        return teacherService.getTeacherById(id);
    }

    @PostMapping
    public Result createTeacher(@RequestBody TeacherController.TeacherNoPassword teacher) {
        return teacherService.createTeacher(teacher);
    }

    @PutMapping
    public Result updateTeacher(@RequestParam(required = true, value = "oldId") String oldId, @RequestBody TeacherController.TeacherNoPassword teacher) {
        return teacherService.updateTeacher(oldId, teacher);
    }

    @PutMapping("/info")
    public Result updateTeacherInfo(@RequestBody User user) {
        return teacherService.updateTeacherInfo(user.getId(), user.getEmail(), user.getPassword());
    }

    @DeleteMapping
    public Result deleteTeacherById(@RequestParam(required = true, value = "id") String id) {
        return teacherService.deleteTeacherById(id);
    }


}
