package cn.edu.hit.backend.service;

import cn.edu.hit.backend.controller.CourseOfferingController;
import cn.edu.hit.backend.util.result.Result;

public interface CourseOfferingService {
    Result getOfferingList();
    Result getOfferingById(String id);
    Result createOffering(CourseOfferingController.CourseOfferingWithoutId courseOfferingWithoutId);
    Result updateOffering(CourseOfferingController.CourseOfferingAlterable courseOfferingAlterable);
    Result deleteOffering(String id);
    Result getOptionalOfferingList(String semester, String studentId);
    Result getSelectedOfferingList(String semester, String studentId);
    Result getOfferingListByTeacher(String semester, String teacherId);
}
