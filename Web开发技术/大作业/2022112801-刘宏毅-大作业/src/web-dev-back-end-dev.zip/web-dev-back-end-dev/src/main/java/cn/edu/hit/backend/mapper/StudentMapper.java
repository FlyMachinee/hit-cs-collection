package cn.edu.hit.backend.mapper;

import java.util.List;

import cn.edu.hit.backend.controller.StudentController;
import org.apache.ibatis.annotations.*;
import cn.edu.hit.backend.entity.user.Student;

@Mapper
public interface StudentMapper {
    @Select("select * from student where id=#{id} and password=#{password}")
    Student login(String id, String password);

    @Select("select row_number() over (order by id) as index, * from student")
    List<StudentController.StudentData> findAll();

    @Select("select * from student where id = #{id}")
    Student findById(String id);

    @Delete("delete from student where id = #{id}")
    void delete(String id);

    @Insert("insert into student(id, name, gender, email, major, faculty, password) values(#{id}, #{name}, #{gender}, #{email}, #{major}, #{faculty}, 'hit520')")
    void add(StudentController.StudentNoPassword student);

    @Update("update student set id = #{student.id}, name = #{student.name}, gender = #{student.gender}, email = #{student.email}, major = #{student.major} where id = #{oldId}")
    void update(String oldId, StudentController.StudentNoPassword student);

    @Update("update student set email = #{email}, password = #{password} where id = #{id}")
    void updateInfo(String id, String email, String password);
}
