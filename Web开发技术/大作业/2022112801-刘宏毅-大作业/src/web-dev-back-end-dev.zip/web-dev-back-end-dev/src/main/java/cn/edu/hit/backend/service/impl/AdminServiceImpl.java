package cn.edu.hit.backend.service.impl;

import cn.edu.hit.backend.controller.LoginController;
import cn.edu.hit.backend.entity.user.Admin;
import cn.edu.hit.backend.mapper.AdminMapper;
import cn.edu.hit.backend.service.AdminService;
import cn.edu.hit.backend.util.jwt.JWTUtil;
import cn.edu.hit.backend.util.result.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminMapper adminMapper;

    @Override
    public Result login(String id, String password) {
        Admin admin = adminMapper.login(id, password);
        if (admin == null) {
            return new Result(406, "用户名或密码错误！", null);
        } else {
            String token = JWTUtil.makeJWS("admin", 60 * 60);
            return new Result(new LoginController.LoginOutputData(token, adminMapper.getAdminById(id)));
        }
    }

    @Override
    public Result updateAdminInfo(String id, String email, String password) {
        try {
            adminMapper.updateInfo(id, email, password);
        } catch (Exception e) {
            return new Result(400, "修改管理员信息失败", null);
        }
        return new Result(null);
    }

}
