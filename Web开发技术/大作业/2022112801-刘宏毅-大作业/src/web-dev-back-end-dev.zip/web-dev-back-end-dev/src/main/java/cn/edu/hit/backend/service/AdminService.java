package cn.edu.hit.backend.service;

import cn.edu.hit.backend.util.result.Result;

public interface AdminService {
    Result login(String id, String password);
    Result updateAdminInfo(String id, String email, String password);
}
