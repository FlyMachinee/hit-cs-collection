package cn.edu.hit.backend.entity.user;

import java.util.Set;

import cn.edu.hit.backend.entity.course.CourseRegistration;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
public class Student extends User {
    private String faculty;
    private String major;

    public Student(String id, String name, String password, String email, String gender, String faculty, String major) {
        super(id, name, password, email, gender);
        this.faculty = faculty;
        this.major = major;
    }
}
