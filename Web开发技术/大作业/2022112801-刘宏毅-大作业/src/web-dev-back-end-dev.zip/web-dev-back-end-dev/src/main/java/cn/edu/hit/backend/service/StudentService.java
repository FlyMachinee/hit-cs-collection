package cn.edu.hit.backend.service;

import cn.edu.hit.backend.controller.StudentController;
import cn.edu.hit.backend.util.result.Result;

public interface StudentService {
    Result login(String id, String password);
    Result getStudentList();
    Result getStudentById(String id);
    Result createStudent(StudentController.StudentNoPassword student);
    Result updateStudent(String oldId, StudentController.StudentNoPassword student);
    Result updateStudentInfo(String id, String email, String password);
    Result deleteStudentById(String id);
}
