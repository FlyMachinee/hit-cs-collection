package cn.edu.hit.backend.service.impl;

import cn.edu.hit.backend.controller.CourseController;
import cn.edu.hit.backend.entity.course.Course;
import cn.edu.hit.backend.mapper.CourseMapper;
import cn.edu.hit.backend.service.CourseService;
import cn.edu.hit.backend.util.result.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CourseServiceImpl implements CourseService {

    @Autowired
    private CourseMapper courseMapper;

    @Override
    public Result getCourseList() {
        try {
            return new Result(courseMapper.findAll());
        } catch (Exception e) {
            return new Result(400, "课程查询失败", null);
        }
    }

    @Override
    public Result getCourseById(String id) {
        try {
            return new Result(courseMapper.findById(id));
        } catch (Exception e) {
            return new Result(400, "课程查询失败", null);
        }
    }

    @Override
    public Result createCourse(Course course) {
        try {
            courseMapper.add(course);
        } catch (Exception e) {
            return new Result(400, "课程创建失败", null);
        }
        return new Result(null);
    }

    @Override
    public Result updateCourse(CourseController.UpdateData updateData) {
        try {
            courseMapper.update(updateData);
        } catch (Exception e) {
            return new Result(400, "课程更新失败", null);
        }
        return new Result(null);
    }

    @Override
    public Result deleteCourseById(String id) {
        try {
            courseMapper.delete(id);
        } catch (Exception e) {
            return new Result(400, "课程删除失败", null);
        }
        return new Result(null);
    }
}
