package cn.edu.hit.backend.service.impl;

import cn.edu.hit.backend.controller.CourseRegistrationController;
import cn.edu.hit.backend.entity.course.CourseRegistration;
import cn.edu.hit.backend.mapper.CourseRegistrationMapper;
import cn.edu.hit.backend.service.CourseRegistrationService;
import cn.edu.hit.backend.util.result.Result;
import cn.edu.hit.backend.util.uuid.UUIDMaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseRegistrationServiceImpl implements CourseRegistrationService {

    @Autowired
    private CourseRegistrationMapper courseRegistrationMapper;

    @Override
    public Result registerCourse(String studentId, String offeringId) {
        System.out.println("hhhhhh");
        try {
            courseRegistrationMapper.createCourseRegistration(
                    new CourseRegistration(
                            UUIDMaker.getUUID(),
                            studentId,
                            offeringId,
                            null
                    )
            );
        } catch (Exception e) {
            return new Result(400, "学生选课失败", null);
        }
        return new Result(null);
    }

    @Override
    public Result withdrawCourse(String studentId, String offeringId) {
        try {
            courseRegistrationMapper.deleteCourseRegistration(studentId, offeringId);
        } catch (Exception e) {
            return new Result(400, "学生退课失败", null);
        }
        return new Result(null);
    }

    @Override
    public Result getScoreForStudent(String studentId) {
        try {
            List<CourseRegistrationController.Data> res = courseRegistrationMapper.getScoreForStudent(studentId);
            float gradePointsSum = 0, creditsSum = 0;
            for (CourseRegistrationController.Data d : res) {
                gradePointsSum += d.getGradePoint();
                creditsSum += d.getCredits();
            }
            return new Result(new CourseRegistrationController.ScoreForStudent(gradePointsSum / creditsSum, res));
        } catch (Exception e) {
            return new Result(400, "学生查分失败", null);
        }
    }

    @Override
    public Result getScoreForTeacher(String offeringId) {
        try {
            return new Result(courseRegistrationMapper.getScoreForTeacher(offeringId));
        } catch (Exception e) {
            return new Result(400, "教师查分失败", null);
        }
    }

    @Override
    public Result getScoreForAdmin(String offeringId) {
        try {
            return new Result(courseRegistrationMapper.getScoreForAdmin(offeringId));
        } catch (Exception e) {
            return new Result(400, "管理员查分失败", null);
        }
    }

    @Override
    public Result registerScore(CourseRegistrationController.ScoreForTeacher[] registrationList) {
        try {
            for (CourseRegistrationController.ScoreForTeacher s : registrationList) {
                courseRegistrationMapper.registrationScore(s.getId(), s.getScore());
            }
        } catch (Exception e) {
            return new Result(400, "教师登分失败", null);
        }
        return new Result(null);
    }
}
