package cn.edu.hit.backend.controller;

import cn.edu.hit.backend.entity.course.Course;
import cn.edu.hit.backend.service.CourseService;
import cn.edu.hit.backend.util.result.Result;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/course")
@CrossOrigin
public class CourseController {

    @Autowired
    private CourseService courseService;

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class CourseData extends Course{
        private int index;
    }

    @GetMapping("/all")
    public Result getCourseList() {
        return courseService.getCourseList();
    }

    @GetMapping
    public Result getCourseById(@RequestParam(required = true, name = "id") String id) {
        return courseService.getCourseById(id);
    }

    @PostMapping
    public Result createCourse(@RequestBody Course course) {
        return courseService.createCourse(course);
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class UpdateData extends Course{
        private String oldId;
    }

    @PutMapping
    public Result updateCourse(@RequestBody UpdateData updateData) {
        return courseService.updateCourse(updateData);
    }

    @DeleteMapping
    public Result deleteCourseById(@RequestParam(required = true, name = "id") String id) {
        return courseService.deleteCourseById(id);
    }
}
