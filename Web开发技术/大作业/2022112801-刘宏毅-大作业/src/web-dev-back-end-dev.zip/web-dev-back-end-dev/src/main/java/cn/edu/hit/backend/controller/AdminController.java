package cn.edu.hit.backend.controller;

import cn.edu.hit.backend.entity.user.User;
import cn.edu.hit.backend.service.AdminService;
import cn.edu.hit.backend.util.result.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
@CrossOrigin
public class AdminController {

    @Autowired
    private AdminService adminService;

    @PutMapping("/info")
    public Result updateAdminInfo(@RequestBody User user) {
        return adminService.updateAdminInfo(user.getId(), user.getEmail(), user.getPassword());
    }
}
