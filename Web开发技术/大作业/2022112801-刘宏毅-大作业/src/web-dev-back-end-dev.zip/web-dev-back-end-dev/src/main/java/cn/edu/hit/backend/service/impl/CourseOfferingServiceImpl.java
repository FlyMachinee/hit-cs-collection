package cn.edu.hit.backend.service.impl;

import cn.edu.hit.backend.controller.CourseOfferingController;
import cn.edu.hit.backend.entity.course.CourseOffering;
import cn.edu.hit.backend.mapper.CourseOfferingMapper;
import cn.edu.hit.backend.service.CourseOfferingService;
import cn.edu.hit.backend.util.result.Result;
import cn.edu.hit.backend.util.uuid.UUIDMaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CourseOfferingServiceImpl implements CourseOfferingService {
    @Autowired
    private CourseOfferingMapper courseOfferingMapper;

    @Override
    public Result getOfferingList() {
        try {
            return new Result(courseOfferingMapper.findAll());
        } catch (Exception e) {
            return new Result(400, "排课查询失败", null);
        }
    }

    @Override
    public Result getOfferingById(String id) {
        try {
            return new Result(courseOfferingMapper.findById(id));
        } catch (Exception e) {
            return new Result(400, "排课查询失败", null);
        }
    }

    @Override
    public Result createOffering(CourseOfferingController.CourseOfferingWithoutId courseOfferingWithoutId) {
        try {
            courseOfferingMapper.add(new CourseOffering(UUIDMaker.getUUID(), courseOfferingWithoutId));
        } catch (Exception e) {
            return new Result(400, "排课添加失败", null);
        }
        return new Result(null);
    }

    @Override
    public Result updateOffering(CourseOfferingController.CourseOfferingAlterable courseOfferingAlterable) {
        try {
            courseOfferingMapper.update(courseOfferingAlterable);
        } catch (Exception e) {
            return new Result(400, "排课更新失败", null);
        }
        return new Result(null);
    }

    @Override
    public Result deleteOffering(String id) {
        try {
            courseOfferingMapper.delete(id);
        } catch (Exception e) {
            return new Result(400, "排课删除失败", null);
        }
        return new Result(null);
    }

    @Override
    public Result getOptionalOfferingList(String semester, String studentId) {
        try {
            return new Result(courseOfferingMapper.getOptionalOfferingList(semester, studentId));
        } catch (Exception e) {
            return new Result(400, "排课查询失败", null);
        }
    }

    @Override
    public Result getSelectedOfferingList(String semester, String studentId) {
        try {
            return new Result(courseOfferingMapper.getSelectedOfferingList(semester, studentId));
        } catch (Exception e) {
            return new Result(400, "排课查询失败", null);
        }
    }

    @Override
    public Result getOfferingListByTeacher(String semester, String teacherId) {
        try {
            return new Result(courseOfferingMapper.getOfferingListByTeacher(semester, teacherId));
        } catch (Exception e) {
            return new Result(400, "排课查询失败", null);
        }
    }
}
