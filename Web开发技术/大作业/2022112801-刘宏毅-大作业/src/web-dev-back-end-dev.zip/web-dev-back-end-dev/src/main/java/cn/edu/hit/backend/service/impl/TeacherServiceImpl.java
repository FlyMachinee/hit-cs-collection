package cn.edu.hit.backend.service.impl;

import cn.edu.hit.backend.controller.LoginController;
import cn.edu.hit.backend.controller.TeacherController;
import cn.edu.hit.backend.entity.user.Teacher;
import cn.edu.hit.backend.mapper.TeacherMapper;
import cn.edu.hit.backend.service.TeacherService;
import cn.edu.hit.backend.util.jwt.JWTUtil;
import cn.edu.hit.backend.util.result.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TeacherServiceImpl implements TeacherService {

    @Autowired
    private TeacherMapper teacherMapper;

    @Override
    public Result login(String id, String password) {
        Teacher teacher = teacherMapper.login(id, password);
        if (teacher == null) {
            return new Result(406, "用户名或密码错误！", null);
        } else {
            String token = JWTUtil.makeJWS("teacher", 60 * 60);
            return new Result(new LoginController.LoginOutputData(token, teacherMapper.findById(id)));
        }
    }

    @Override
    public Result getTeacherList() {
        try {
            return new Result(teacherMapper.findAll());
        } catch (Exception e) {
            return new Result(400, "查询教师失败", null);
        }
    }

    @Override
    public Result getTeacherById(String id) {
        try {
            return new Result(teacherMapper.findById(id));
        } catch (Exception e) {
            return new Result(400, "查询教师失败", null);
        }
    }

    @Override
    public Result createTeacher(TeacherController.TeacherNoPassword teacher) {
        try {
            teacherMapper.add(teacher);
        } catch (Exception e) {
            return new Result(400, "添加教师失败", null);
        }
        return new Result(null);
    }

    @Override
    public Result updateTeacher(String oldId, TeacherController.TeacherNoPassword teacher) {
        try {
            teacherMapper.update(oldId, teacher);
        } catch (Exception e) {
            return new Result(400, "修改教师失败", null);
        }
        return new Result(null);
    }

    @Override
    public Result updateTeacherInfo(String id, String email, String password) {
        try {
            teacherMapper.updateInfo(id, email, password);
        } catch (Exception e) {
            return new Result(400, "修改教师信息失败", null);
        }
        return new Result(null);
    }

    @Override
    public Result deleteTeacherById(String id) {
        try {
            teacherMapper.delete(id);
        } catch (Exception e) {
            return new Result(400, "删除教师失败", null);
        }
        return new Result(null);
    }
}
