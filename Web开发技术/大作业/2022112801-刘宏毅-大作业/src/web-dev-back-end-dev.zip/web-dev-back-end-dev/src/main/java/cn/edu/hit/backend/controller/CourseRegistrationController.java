package cn.edu.hit.backend.controller;

import cn.edu.hit.backend.service.CourseRegistrationService;
import cn.edu.hit.backend.util.result.Result;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/courseRegistration")
@CrossOrigin
public class CourseRegistrationController {

    @Autowired
    private CourseRegistrationService courseRegistrationService;

    @PostMapping
    public Result registerCourse(@RequestParam(required = true, name = "studentId") String studentId,
                                 @RequestParam(required = true, name = "offeringId") String offeringId) {
        return courseRegistrationService.registerCourse(studentId, offeringId);
    }

    @DeleteMapping
    public Result withdrawCourse(@RequestParam(required = true, name = "studentId") String studentId,
                                 @RequestParam(required = true, name = "offeringId") String offeringId) {
        return courseRegistrationService.withdrawCourse(studentId, offeringId);
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Data {
        private String id;
        private String code;
        private String name;
        private String faculty;
        private float credits;
        private float score;
        private float gradePoint;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ScoreForStudent {
        private double GPA;
        private List<Data> scoreList;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ScoreForTeacher {
        private String id;
        private String studentId;
        private String studentName;
        private String studentEmail;
        private String faculty;
        private Double score;
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ScoreForAdmin {
        private String index;
        private String studentId;
        private String studentName;
        private String studentEmail;
        private String faculty;
        private Double score;
    }

    @GetMapping("/score/student")
    public Result getScoreForStudent(@RequestParam(required = true, name = "studentId") String studentId) {
        return courseRegistrationService.getScoreForStudent(studentId);
    }

    @GetMapping("/score/teacher/get")
    public Result getScoreForTeacher(@RequestParam(required = true, name = "offeringId") String offeringId) {
        return courseRegistrationService.getScoreForTeacher(offeringId);
    }

    @GetMapping("/score/admin")
    public Result getScoreForAdmin(@RequestParam(required = true, name = "offeringId") String offeringId) {
        return courseRegistrationService.getScoreForAdmin(offeringId);
    }

    @PutMapping("/score/teacher/set")
    public Result registerScore(@RequestBody ScoreForTeacher[] registrationList) {
        return courseRegistrationService.registerScore(registrationList);
    }
}
