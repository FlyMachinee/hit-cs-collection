package cn.edu.hit.backend.entity.course;

import cn.edu.hit.backend.controller.CourseOfferingController;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CourseOffering {
    private String id;
    private String courseId;
    private String teacherId;
    private String place;
    private String semester;
    private Integer startWeek;
    private Integer endWeek;
    private Integer startPeriod;
    private Integer endPeriod;

    public CourseOffering(String id, CourseOfferingController.CourseOfferingWithoutId courseOfferingWithoutId) {
        this.id = id;
        courseId = courseOfferingWithoutId.getCourseId();
        teacherId = courseOfferingWithoutId.getTeacherId();
        place = courseOfferingWithoutId.getPlace();
        semester = courseOfferingWithoutId.getSemester();
        startWeek = courseOfferingWithoutId.getStartWeek();
        endWeek = courseOfferingWithoutId.getEndWeek();
        startPeriod = courseOfferingWithoutId.getStartPeriod();
        endPeriod = courseOfferingWithoutId.getEndPeriod();
    }
}
