package cn.edu.hit.backend.service;

import cn.edu.hit.backend.controller.CourseController;
import cn.edu.hit.backend.entity.course.Course;
import cn.edu.hit.backend.util.result.Result;

public interface CourseService {
    Result getCourseList();
    Result getCourseById(String id);
    Result createCourse(Course course);
    Result updateCourse(CourseController.UpdateData updateData);
    Result deleteCourseById(String id);
}
