package cn.edu.hit.backend.mapper;

import cn.edu.hit.backend.controller.CourseController;
import cn.edu.hit.backend.entity.course.Course;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CourseMapper {

    @Select("select row_number() over (order by id) as index, * from course")
    List<CourseController.CourseData> findAll();

    @Select("select * from course where id = #{id}")
    Course findById(String id);

    @Delete("delete from course where id = #{id}")
    void delete(String id);

    @Insert("insert into course(id, name, credits, description) values(#{id}, #{name}, #{credits}, #{description})")
    void add(Course course);

    @Update("update course set id = #{id}, name = #{name}, credits = #{credits}, description = #{description} where id = #{oldId}")
    void update(CourseController.UpdateData updateData);

}
