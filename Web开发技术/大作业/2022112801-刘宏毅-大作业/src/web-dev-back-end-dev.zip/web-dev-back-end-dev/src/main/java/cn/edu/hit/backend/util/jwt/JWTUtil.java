package cn.edu.hit.backend.util.jwt;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;

import javax.crypto.SecretKey;
import java.sql.Date;

public class JWTUtil {

    private static final SecretKey KEY = Jwts.SIG.HS256.key().build();

    public static String makeJWS(String role, int durationSec) {
        Date expireTime = new Date(System.currentTimeMillis() + durationSec * 1000L);
        return Jwts.builder().expiration(expireTime).claim("role", role).signWith(KEY).compact();
    }

    public static CheckResult checkJWS(String token, String role) {
        try {
            Claims claims = Jwts.parser().verifyWith(KEY).build().parseSignedClaims(token).getPayload();
            if (claims.get("role").equals(role)) {
                return CheckResult.OK;
            } else {
                return CheckResult.UNAUTHORIZED;
            }
        }
        catch (ExpiredJwtException e) {
            return CheckResult.EXPIRED;
        }
        catch (JwtException e) {
            return CheckResult.INVALID;
        }
    }

    public enum CheckResult {
        OK, INVALID, UNAUTHORIZED, EXPIRED
        // 检查成功， 非法token， 权限不匹配， token过期
    }
}
