package cn.edu.hit.backend.entity.user;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
public class Admin extends User {
    public Admin(String id, String name, String password, String email, String gender) {
        super(id, name, password, email, gender);
    }
}
