package cn.edu.hit.backend.util.result;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Result {
    private int code;
    private String msg;
    private Object data;

    public Result(String msg, Object data) {
        code = 200;
        this.msg = msg;
        this.data = data;
    }

    public Result(Object data) {
        code = 200;
        msg = "OK";
        this.data = data;
    }
}
