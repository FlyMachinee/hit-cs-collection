package cn.edu.hit.backend.mapper;

import cn.edu.hit.backend.controller.CourseOfferingController;
import cn.edu.hit.backend.entity.course.CourseOffering;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CourseOfferingMapper {
    @Select("select " +
            "row_number() over (order by semester) as index," +
            "id, " +
            "(select name from course where course.id = course_id) as courseName, " +
            "(select name from teacher where teacher.id = teacher_id) as teacherName, " +
            "place, semester, start_week as startWeek, end_week as endWeek, start_period as startPeriod, end_period as endPeriod " +
            "from course_offering")
    List<CourseOfferingController.CourseOfferingData> findAll();

    @Select("select id, course_id as courseId, teacher_id as teacherId, place, semester, start_week as startWeek, end_week as endWeek, start_period as startPeriod, end_period as endPeriod from course_offering where id = #{id}")
    CourseOffering findById(String id);

    @Insert("insert into course_offering(id, course_id, teacher_id, place, semester, start_week, end_week, start_period, end_period) values " +
            "(#{id}, #{courseId}, #{teacherId}, #{place}, #{semester}, #{startWeek}, #{endWeek}, #{startPeriod}, #{endPeriod})")
    void add(CourseOffering courseOffering);

    @Update("update course_offering set place = #{place}, semester = #{semester}, start_week = #{startWeek}, end_week = #{endWeek}, start_period = #{startPeriod}, end_period = #{endPeriod} where id = #{id}")
    void update(CourseOfferingController.CourseOfferingAlterable courseOfferingAlterable);

    @Delete("delete from course_offering where id = #{id}")
    void delete(String id);

    @Select("select " +
            "course_offering.id as id, " +
            "course_id as code, " +
            "name as name, " +
            "description as info, " +
            "(select teacher.faculty from teacher where teacher.id = course_offering.teacher_id) as faculty, " +
            "credits as credits, " +
            "floor(credits * 16) as hours " +
            "from course_offering, course " +
            "where course_id = course.id and semester = #{semester} and " +
            "course_offering.id not in " +
            "(select offering_id from course_registration where student_id = #{studentId}) " +
            "order by course_id")
    List<CourseOfferingController.Data> getOptionalOfferingList(String semester, String studentId);

    @Select("select " +
            "course_offering.id as id, " +
            "course_id as code, " +
            "course.name as name, " +
            "course.description as info, " +
            "(select teacher.faculty from teacher where teacher.id = course_offering.teacher_id) as faculty, " +
            "credits as credits, " +
            "floor(credits * 16) as hours " +
            "from course_offering, course " +
            "where course_id = course.id and semester = #{semester} and " +
            "course_offering.id in " +
            "(select offering_id from course_registration where student_id = #{studentId}) " +
            "order by course_id")
    List<CourseOfferingController.Data> getSelectedOfferingList(String semester, String studentId);

    @Select("select " +
            "course_offering.id as id, " +
            "course_id as code, " +
            "course.name as name, " +
            "course.credits as credits, " +
            "floor(credits * 16) as hours " +
            "from course_offering, course " +
            "where course_id = course.id and semester = #{semester} and teacher_id = #{teacherId} " +
            "order by course_id ")
    List<CourseOfferingController.TeacherOffering> getOfferingListByTeacher(String semester, String teacherId);
}
