import React from "react";
import { RouterProvider } from "react-router-dom";
import router from "./router";
import Loading from "./components/loading";

const App = () => {
  return (
    <React.Suspense fallback={<Loading />}>
      <RouterProvider router={router} />
    </React.Suspense>
  );
};

export default App;
