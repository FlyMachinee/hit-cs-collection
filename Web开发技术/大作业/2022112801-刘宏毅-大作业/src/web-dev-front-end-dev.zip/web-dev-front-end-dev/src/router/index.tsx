/* eslint-disable react-refresh/only-export-components */
import { Navigate, Outlet, createBrowserRouter } from "react-router-dom";
import { lazy } from "react";

import TopView from "@/layout";
import ScoreInquiry from "@/views/student/score-inquiry";
import Register from "@/views/student/register";
import CourseManagement from "@/views/admin/course-management";
import StudentManagement from "@/views/admin/student-management";
import TeacherManagement from "@/views/admin/teacher-management";
import ScoreQuery from "@/views/admin/score-query";
import OfferingManagement from "@/views/admin/course-offering-management";
import OfferingManagementForTeacher from "@/views/teacher/offering-manage";
import ScoreManagement from "@/views/teacher/offering-manage/score-manage";
import AccountSettings from "@/views/settings";
import ScoreQueryByOffering from "@/views/admin/score-query/score-query-by-offering";
import Error404 from "@/views/404";
import RouteGuard from "./router-guard";

const Login = lazy(() => import("../views/login"));

export const routes = [
  {
    path: "",
    element: <Navigate to="/login" />,
  },
  {
    path: "*",
    element: <Error404 />,
  },
  {
    path: "login",
    element: <Login />,
  },
  {
    path: "/",
    element: (
      <RouteGuard>
        <TopView />
      </RouteGuard>
    ),
    children: [
      {
        path: "settings",
        element: <AccountSettings />,
      },
      {
        path: "student",
        element: <Outlet />,
        children: [
          {
            path: "register",
            element: <Register />,
          },
          {
            path: "score-inquiry",
            element: <ScoreInquiry />,
          },
        ],
      },
      {
        path: "teacher",
        element: <Outlet />,
        children: [
          {
            path: "offering-manage",
            element: <OfferingManagementForTeacher />,
          },
          {
            path: "offering-manage/:id",
            element: <ScoreManagement />,
          },
        ],
      },
      {
        path: "admin",
        element: <Outlet />,
        children: [
          {
            path: "course-management",
            element: <CourseManagement />,
          },
          {
            path: "student-management",
            element: <StudentManagement />,
          },
          {
            path: "teacher-management",
            element: <TeacherManagement />,
          },
          {
            path: "score-query",
            element: <ScoreQuery />,
          },
          {
            path: "score-query/:id",
            element: <ScoreQueryByOffering />,
          },
          {
            path: "course-offering-management",
            element: <OfferingManagement />,
          },
        ],
      },
    ],
  },
];

const router = createBrowserRouter(routes);

export default router;
