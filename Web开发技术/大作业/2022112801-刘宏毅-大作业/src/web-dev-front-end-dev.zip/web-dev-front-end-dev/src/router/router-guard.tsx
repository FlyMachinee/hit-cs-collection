import { useAppSelector } from "@/store/hooks";
import { Navigate, useLocation } from "react-router-dom";

const RouteGuard = ({ children }: { children: React.ReactNode }) => {
  const WhiteList = ["/login"];

  const { pathname } = useLocation();
  const { role } = useAppSelector((state) => state.user.userInfo);

  if (WhiteList.includes(pathname)) {
    return children;
  } else {
    if (
      pathname.split("/")[1] === role ||
      (pathname.split("/")[1] === "settings" && role !== "")
    ) {
      return children;
    } else {
      return <Navigate to="/login" />;
    }
  }
};

export default RouteGuard;
