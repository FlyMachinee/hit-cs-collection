import { TeacherData } from "@/views/admin/teacher-management/types";
import api from "./config";
import { Teacher } from "@/types/teacher";

export const getTeacherList = async (): Promise<TeacherData[]> => {
  console.log("调用了getTeacherList");
  try {
    const res = await api.get(`/teacher/all`);
    // 应该结合返回的状态码
    return res.data.data;
  } catch (e) {
    throw new Error("无法获取教师列表！");
  }
};

export const getTeacherById = async (id: string): Promise<Teacher | null> => {
  console.log("调用了getTeacherById");
  try {
    const res = await api.get(`/teacher?id=${id}`);
    if (res.data.code === 200) {
      return res.data.data;
    } else {
      return null;
    }
  } catch (e) {
    throw new Error("未知错误！");
  }
};

export const createTeacher = async (teacher: Teacher): Promise<boolean> => {
  console.log("调用了createTeacher");
  try {
    const res = await api.post(`/teacher`, teacher);
    return res.data.code === 200;
  } catch (e) {
    throw new Error("未知错误！");
  }
};

export const updateTeacher = async (
  oldId: string,
  newTeacher: Teacher
): Promise<boolean> => {
  console.log("调用了updateTeacher");
  try {
    const res = await api.put(`/teacher?oldId=${oldId}`, newTeacher);
    return res.data.code === 200;
  } catch (e) {
    throw new Error("未知错误！");
  }
};

export const deleteTeacherById = async (id: string): Promise<boolean> => {
  console.log("调用了deleteTeacherById");
  try {
    const res = await api.delete(`/teacher?id=${id}`);
    return res.data.code === 200;
  } catch (e) {
    throw new Error("未知错误！");
  }
};

export const isTeacherIdExist = async (id: string): Promise<boolean> => {
  console.log("调用了isTeacherIdExist");
  return (await getTeacherById(id)) !== null;
};
