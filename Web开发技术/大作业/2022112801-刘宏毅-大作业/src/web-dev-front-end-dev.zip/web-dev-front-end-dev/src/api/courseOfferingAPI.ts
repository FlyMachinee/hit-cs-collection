import { CourseOfferingData } from "./../views/admin/course-offering-management/types";
import { Data } from "@/views/student/register/types";
import api from "./config";
import { Semester } from "@/types/semester";
import { CourseOffering, TeacherOffering } from "@/types/courseOffering";
import {
  CourseOfferingAlterable,
  CourseOfferingWithoutId,
} from "@/types/courseOffering";

export const getOfferingList = async (): Promise<CourseOfferingData[]> => {
  console.log("调用了getOfferingList");
  try {
    const res = await api.get(`/courseOffering/all`);
    return res.data.data;
  } catch (e) {
    throw new Error("无法获取选课列表！");
  }
};

export const getOfferingById = async (id: string): Promise<CourseOffering> => {
  console.log("调用了getOfferingById");
  try {
    const res = await api.get(`/courseOffering?id=${id}`);
    return res.data.data;
  } catch (e) {
    throw new Error("无法获取选课列表！");
  }
};

export const getOptionalOfferingList = async (
  semester: Semester,
  studentId: string
): Promise<Data[]> => {
  console.log("调用了getOptionalOfferingList");
  try {
    const res = await api.get(
      `/courseOffering/optional?semester=${semester}&studentId=${studentId}`
    );
    // 应该结合返回的状态码
    return res.data.data;
  } catch (e) {
    throw new Error("无法获取学生备选课程列表！");
  }
};

export const getSelectedOfferingList = async (
  semester: Semester,
  studentId: string
): Promise<Data[]> => {
  console.log("调用了getSelectedOfferingList");
  try {
    const res = await api.get(
      `/courseOffering/selected?semester=${semester}&studentId=${studentId}`
    );
    // 应该结合返回的状态码
    return res.data.data;
  } catch (e) {
    throw new Error("无法获取学生已选课程列表！");
  }
};

export const getOfferingListByTeacher = async (
  semester: string,
  teacherId: string
): Promise<TeacherOffering[]> => {
  console.log("调用了getOfferingListByTeacher");
  try {
    const res = await api.get(
      `/courseOffering/teacher?semester=${semester}&teacherId=${teacherId}`
    );
    // 应该结合返回的状态码
    return res.data.data;
  } catch (e) {
    throw new Error("无法获取教师开课列表！");
  }
};

export const createOffering = async (
  offering: CourseOfferingWithoutId
): Promise<boolean> => {
  console.log("调用了createOffering");
  try {
    const res = await api.post(`/courseOffering`, offering);
    return res.data.code === 200;
  } catch (e) {
    throw new Error("未知错误！");
  }
};

export const updateOffering = async (
  offering: CourseOfferingAlterable
): Promise<boolean> => {
  console.log("调用了updateOffering");
  try {
    const res = await api.put(`/courseOffering`, offering);
    return res.data.code === 200;
  } catch (e) {
    throw new Error("未知错误！");
  }
};

export const deleteOfferingById = async (id: string): Promise<boolean> => {
  console.log("调用了deleteOfferingById");
  try {
    const res = await api.delete(`/courseOffering?id=${id}`);
    return res.data.code === 200;
  } catch (e) {
    throw new Error("未知错误！");
  }
};
