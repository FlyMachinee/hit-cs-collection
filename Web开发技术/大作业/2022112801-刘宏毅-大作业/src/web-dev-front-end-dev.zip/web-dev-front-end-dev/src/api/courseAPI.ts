import { CourseData } from "@/views/admin/course-management/types";
import api from "./config";
import { Course } from "@/types/course";

export const getCourseList = async (): Promise<CourseData[]> => {
  console.log("调用了getCourseList");
  try {
    const res = await api.get(`/course/all`);
    // 应该结合返回的状态码
    return res.data.data;
  } catch (e) {
    throw new Error("无法获取课程列表！");
  }
};

export const getCourseById = async (id: string): Promise<Course | null> => {
  console.log("调用了getCourseById");
  try {
    const res = await api.get(`/course?id=${id}`);
    if (res.data.code === 200) {
      return res.data.data;
    } else {
      return null;
    }
  } catch (e) {
    throw new Error("未知错误！");
  }
};

export const createCourse = async (course: Course): Promise<boolean> => {
  console.log("调用了createCourse");
  try {
    const res = await api.post(`/course`, {
      ...course,
      description: course.description === "" ? "无" : course.description,
    });
    return res.data.code === 200;
  } catch (e) {
    throw new Error("未知错误！");
  }
};

export const updateCourse = async (
  oldCode: string,
  newCourse: Course
): Promise<boolean> => {
  console.log("调用了updateCourse");
  try {
    const res = await api.put(`/course`, {
      oldId: oldCode,
      ...newCourse,
      description: newCourse.description === "" ? "无" : newCourse.description,
    });
    return res.data.code === 200;
  } catch (e) {
    throw new Error("未知错误！");
  }
};

export const deleteCourseById = async (code: string): Promise<boolean> => {
  console.log("调用了deleteCourseById");
  try {
    const res = await api.delete(`/course?id=${code}`);
    return res.data.code === 200;
  } catch (e) {
    throw new Error("未知错误！");
  }
};

export const isCourseIdExist = async (code: string): Promise<boolean> => {
  console.log("调用了isCourseIdExist");
  return (await getCourseById(code)) === null;
};
