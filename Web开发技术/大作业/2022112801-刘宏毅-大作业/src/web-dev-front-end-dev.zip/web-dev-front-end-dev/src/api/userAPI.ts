import api from "./config";
import { User } from "@/types/user";

export const login = async (
  username: string,
  password: string,
  role: string
): Promise<{
  code: number;
  msg: string;
  data?: User;
}> => {
  console.log("调用了login");
  const res = await api.post("/login", {
    username,
    password,
    role,
  });
  console.log(res);

  const data = res.data;
  if (data.code === 200) {
    localStorage.setItem("token", data.data.token);
    console.log(data.data.token);
  }
  return {
    ...data,
    data: {
      ...data.data.userData,
      role,
    },
  };
};

export const updateInfo = async (userInfo: User): Promise<boolean> => {
  try {
    const res = await api.put(`/${userInfo.role}/info`, userInfo);
    return res.data.code === 200;
  } catch (e) {
    throw new Error("无法更新用户信息！");
  }
};
