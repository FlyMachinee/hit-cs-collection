import { StudentData } from "@/views/admin/student-management/types";
import api from "./config";
import { Student } from "@/types/student";

export const getStudentList = async (): Promise<StudentData[]> => {
  console.log("调用了getStudentList");
  try {
    const res = await api.get(`/student/all`);
    return res.data.data;
  } catch (e) {
    throw new Error("无法获取学生列表！");
  }
};

export const getStudentById = async (id: string): Promise<Student | null> => {
  console.log("调用了getStudentById");
  try {
    const res = await api.get(`/student?id=${id}`);
    if (res.data.code === 200) {
      return res.data.data;
    } else {
      return null;
    }
  } catch (e) {
    throw new Error("未知错误！");
  }
};

export const createStudent = async (student: Student): Promise<boolean> => {
  console.log("调用了createStudent");
  try {
    const res = await api.post(`/student`, student);
    return res.data.code === 200;
  } catch (e) {
    throw new Error("未知错误！");
  }
};

export const updateStudent = async (
  oldId: string,
  newStudent: Student
): Promise<boolean> => {
  console.log("调用了updateStudent");
  try {
    const res = await api.put(`/student?oldId=${oldId}`, newStudent);
    return res.data.code === 200;
  } catch (e) {
    throw new Error("未知错误！");
  }
};

export const deleteStudentById = async (id: string): Promise<boolean> => {
  console.log("调用了deleteStudentById");
  try {
    const res = await api.delete(`/student?id=${id}`);
    return res.data.code === 200;
  } catch (e) {
    throw new Error("未知错误！");
  }
};

export const isStudentIdExist = async (id: string): Promise<boolean> => {
  console.log("调用了isStudentIdExist");
  return (await getStudentById(id)) !== null;
};
