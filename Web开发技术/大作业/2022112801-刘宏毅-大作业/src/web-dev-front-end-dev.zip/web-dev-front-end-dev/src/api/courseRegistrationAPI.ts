import { ScoreForStudent, ScoreForTeacher } from "@/types/courseRegistration";
import api from "./config";
import { ScoreForAdmin } from "@/views/admin/score-query/score-query-by-offering/types";

export const registerCourse = async (
  studentId: string,
  offeringId: string
): Promise<boolean> => {
  console.log("调用了registerCourse");
  try {
    const res = await api.post(
      `/courseRegistration?studentId=${studentId}&offeringId=${offeringId}`
    );
    return res.data.code === 200;
  } catch (e) {
    throw new Error("学生无法选课！");
  }
};

export const withdrawCourse = async (
  studentId: string,
  offeringId: string
): Promise<boolean> => {
  console.log("调用了withdrawCourse");
  try {
    const res = await api.delete(
      `/courseRegistration?studentId=${studentId}&offeringId=${offeringId}`
    );
    return res.data.code === 200;
  } catch (e) {
    throw new Error("学生无法退课！");
  }
};

export const getScoreForStudent = async (
  studentId: string
): Promise<ScoreForStudent> => {
  console.log("调用了getScoreForStudent");
  try {
    const res = await api.get(
      `/courseRegistration/score/student?studentId=${studentId}`
    );
    return res.data.data;
  } catch (e) {
    throw new Error("学生无法查分！");
  }
};

export const getScoreForTeacher = async (
  offeringId: string
): Promise<ScoreForTeacher[]> => {
  console.log("调用了getScoreForTeacher");
  try {
    const res = await api.get(
      `/courseRegistration/score/teacher/get?offeringId=${offeringId}`
    );
    return res.data.data;
  } catch (e) {
    throw new Error("教师无法查分！");
  }
};

export const getScoreForAdmin = async (
  offeringId: string
): Promise<ScoreForAdmin[]> => {
  console.log("调用了getScoreForAdmin");
  try {
    const res = await api.get(
      `/courseRegistration/score/admin?offeringId=${offeringId}`
    );
    return res.data.data;
  } catch (e) {
    throw new Error("管理员无法查分！");
  }
};

export const registerScore = async (
  registrationList: ScoreForTeacher[]
): Promise<boolean> => {
  console.log("调用了registerScore");
  try {
    const res = await api.put(
      `/courseRegistration/score/teacher/set`,
      registrationList
    );
    return res.data.code === 200;
  } catch (e) {
    throw new Error("教师无法录入成绩！");
  }
};
