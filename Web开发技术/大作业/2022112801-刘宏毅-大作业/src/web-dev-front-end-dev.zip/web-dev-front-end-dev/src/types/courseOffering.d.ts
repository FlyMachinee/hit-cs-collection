import { CourseOffering } from "@/types/courseOffering";
import { Semester } from "./semester";
export interface CourseOffering {
  id: string;
  courseId: string;
  teacherId: string;
  place: string;
  semester: Semester;
  startWeek: number;
  endWeek: number;
  startPeriod: number;
  endPeriod: number;
}

export interface CourseOfferingAlterable {
  id: string;
  place: string;
  semester: Semester;
  startWeek: number;
  endWeek: number;
  startPeriod: number;
  endPeriod: number;
}

export type CourseOfferingWithoutId = Omit<CourseOffering, "id">;

export interface TeacherOffering {
  id: string;
  code: string;
  name: string;
  credits: number;
  hours: number;
}
