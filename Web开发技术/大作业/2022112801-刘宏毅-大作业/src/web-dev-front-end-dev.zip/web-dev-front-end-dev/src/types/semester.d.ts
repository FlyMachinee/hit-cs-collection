type Season = "sp" | "su" | "fa" | "wi";

export type Semester = `${number}${Season}` | "";

export const semesterList: { value: Semester; label: string }[] = [
  {
    value: "2024sp",
    label: "2024春季",
  },
  {
    value: "2023fa",
    label: "2023秋季",
  },
  {
    value: "2023su",
    label: "2023夏季",
  },
  {
    value: "2023sp",
    label: "2023春季",
  },
  {
    value: "2022fa",
    label: "2022秋季",
  },
];
