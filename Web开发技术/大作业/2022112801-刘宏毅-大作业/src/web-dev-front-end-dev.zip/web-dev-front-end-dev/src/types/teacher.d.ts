export interface Teacher {
  id: string;
  name: string;
  gender: string;
  email: string;
  title: string;
  faculty: string;
}
