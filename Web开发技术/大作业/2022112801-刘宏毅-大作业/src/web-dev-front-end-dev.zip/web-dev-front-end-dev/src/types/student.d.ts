export interface Student {
  id: string;
  name: string;
  gender: string;
  email: string;
  major: string;
  faculty: string;
}
