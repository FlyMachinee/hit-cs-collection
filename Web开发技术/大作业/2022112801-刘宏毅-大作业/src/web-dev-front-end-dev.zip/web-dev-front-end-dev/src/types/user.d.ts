export interface User {
  name: string;
  gender: string;
  id: string;
  role: string;
  email: string;
  title?: string;
  faculty?: string;
  password: string;
}
