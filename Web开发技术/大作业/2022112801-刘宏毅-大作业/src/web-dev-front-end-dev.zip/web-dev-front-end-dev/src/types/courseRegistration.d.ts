import { Data } from "@/views/student/score-inquiry/types";

export interface ScoreForStudent {
  gpa: number;
  scoreList: Data[];
}

export interface ScoreForTeacher {
  id: string;
  studentId: string;
  studentName: string;
  studentEmail: string;
  faculty: string;
  score: number;
}
