import Card from "@mui/material/Card";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import TableSortLabel from "@mui/material/TableSortLabel";
import Paper from "@mui/material/Paper";
import { visuallyHidden } from "@mui/utils";
import { Order } from "@/types/order";
import { getComparator, stableSort } from "@/utils/sort";
import React, { useEffect, useMemo, useState } from "react";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import SendIcon from "@mui/icons-material/Send";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { Box, TextField, Typography } from "@mui/material";
import { headCells } from "./data";
import { ScoreForAdmin as TableRowType } from "./types";
import { getScoreForAdmin } from "@/api/courseRegistrationAPI";
import { useNavigate, useParams } from "react-router-dom";
import { getCourseById } from "@/api/courseAPI";
import { getOfferingById } from "@/api/courseOfferingAPI";

interface EnhancedTableProps {
  onRequestSort: (
    event: React.MouseEvent<unknown>,
    property: keyof TableRowType
  ) => void;
  order: Order;
  orderBy: string;
}

const EnhancedTableHead = (props: EnhancedTableProps) => {
  const { order, orderBy, onRequestSort } = props;
  const createSortHandler =
    (property: keyof TableRowType) => (event: React.MouseEvent<unknown>) => {
      onRequestSort(event, property);
    };

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <TableCell
            key={headCell.id}
            align={headCell.numeric ? "right" : "left"}
            padding={headCell.disablePadding ? "none" : "normal"}
            sortDirection={orderBy === headCell.id ? order : false}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <Box component="span" sx={visuallyHidden}>
                  {order === "desc" ? "sorted descending" : "sorted ascending"}
                </Box>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
};

const ScoreQueryByOffering = () => {
  const [order, setOrder] = useState<Order>("asc");
  const [orderBy, setOrderBy] = useState<keyof TableRowType>("index");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  const [rows, setRows] = useState<TableRowType[]>([]);
  const [studentName, setStudentName] = useState("");

  const params = useParams();
  const offeringId = params.id as string;

  const [courseId, setCourseId] = useState("");
  const [courseName, setCourseName] = useState("");

  const navigate = useNavigate();

  const getCourseInfo = async () => {
    const offering = await getOfferingById(offeringId);
    const id = offering.courseId;
    setCourseId(id);
    setCourseName((await getCourseById(id))!.name);
  };

  useEffect(() => {
    handleQuery();
    getCourseInfo();
  }, []);

  const handleQuery = async () => {
    const originRows = await getScoreForAdmin(offeringId);
    const filteredRows = originRows.filter(
      (row) => studentName === "" || row.studentName.includes(studentName)
    );
    setRows(filteredRows);
  };

  const handleRequestSort = (
    _: React.MouseEvent<unknown>,
    property: keyof TableRowType
  ) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleChangePage = (_: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

  const visibleRows = useMemo(
    () =>
      stableSort(rows, getComparator(order, orderBy)).slice(
        page * rowsPerPage,
        page * rowsPerPage + rowsPerPage
      ),
    [order, orderBy, page, rows, rowsPerPage]
  );

  return (
    <Card>
      <Box sx={{ p: 2 }}>
        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          sx={{ mb: 2 }}
        >
          <Stack
            direction="row"
            justifyContent="flex-start"
            alignItems="center"
            sx={{
              "& > :not(style)": { mr: 1, width: "25ch" },
            }}
          >
            <TextField
              id="outlined-search"
              label="学生姓名"
              type="search"
              name="student-name"
              value={studentName}
              onChange={(e) => setStudentName(e.target.value)}
            />
            <Typography sx={{ fontSize: 10 }}>
              {"课程代码：" + courseId + "，课程名：" + courseName}
            </Typography>
          </Stack>
          <Box>
            <Button
              variant="contained"
              endIcon={<SendIcon />}
              onClick={handleQuery}
              sx={{ mr: 1 }}
            >
              查询
            </Button>
            <Button
              variant="contained"
              endIcon={<ArrowBackIcon />}
              onClick={() => navigate("/admin/score-query")}
              sx={{ mr: 1 }}
            >
              返回
            </Button>
          </Box>
        </Stack>
        <Paper sx={{ width: "100%", mb: 2 }}>
          <TableContainer>
            <Table
              sx={{ minWidth: 750 }}
              aria-labelledby="tableTitle"
              size={"medium"}
            >
              <EnhancedTableHead
                order={order}
                orderBy={orderBy}
                onRequestSort={handleRequestSort}
              />
              <TableBody>
                {visibleRows.map((row, index) => {
                  const labelId = `enhanced-table-checkbox-${index}`;

                  return (
                    <TableRow
                      hover
                      role="checkbox"
                      tabIndex={-1}
                      key={row.index}
                      sx={{ cursor: "pointer" }}
                    >
                      <TableCell
                        component="th"
                        id={labelId}
                        scope="row"
                        padding="none"
                        align="right"
                      >
                        {row.index}
                      </TableCell>
                      <TableCell align="left">{row.studentId}</TableCell>
                      <TableCell align="left">{row.studentName}</TableCell>
                      <TableCell align="left">{row.studentEmail}</TableCell>
                      <TableCell align="left">{row.faculty}</TableCell>
                      <TableCell align="right">{row.score}</TableCell>
                    </TableRow>
                  );
                })}
                {emptyRows > 0 && (
                  <TableRow
                    style={{
                      height: 53 * emptyRows,
                    }}
                  >
                    <TableCell colSpan={6} />
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={rows.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Paper>
      </Box>
    </Card>
  );
};

export default ScoreQueryByOffering;
