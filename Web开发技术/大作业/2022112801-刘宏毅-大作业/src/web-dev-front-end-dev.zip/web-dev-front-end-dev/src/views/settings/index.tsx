/** MUI */
import { Box } from "@mui/material";
import Card from "@mui/material/Card";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import TabContext from "@mui/lab/TabContext";

/** React */
import { SyntheticEvent, useState } from "react";

/** Icons Imports */
import PersonIcon from "@mui/icons-material/Person";
import LockOpenIcon from "@mui/icons-material/LockOpen";

/** Demo Tabs Imports */
import TabInfo from "./tab-info";
import TabSecurity from "./tab-security";

/** Utils */
import { Tab, TabName } from "@/components/tab";

const AccountSettings: React.FC = () => {
  const [value, setValue] = useState<string>("info");

  const handleChange = (event: SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  return (
    <Card>
      <TabContext value={value}>
        <TabList
          onChange={handleChange}
          aria-label="account-settings tabs"
          sx={{ borderBottom: (theme) => `1px solid ${theme.palette.divider}` }}
        >
          <Tab
            value="info"
            label={
              <Box sx={{ display: "flex", alignItems: "center" }}>
                <PersonIcon />
                <TabName>个人信息</TabName>
              </Box>
            }
          />
          <Tab
            value="security"
            label={
              <Box sx={{ display: "flex", alignItems: "center" }}>
                <LockOpenIcon />
                <TabName>账号安全</TabName>
              </Box>
            }
          />
        </TabList>

        <TabPanel sx={{ p: 2 }} value="info">
          <TabInfo />
        </TabPanel>
        <TabPanel sx={{ p: 2 }} value="security">
          <TabSecurity />
        </TabPanel>
      </TabContext>
    </Card>
  );
};

export default AccountSettings;
