/* eslint-disable @typescript-eslint/no-explicit-any */
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import { Fragment, memo, useEffect, useState } from "react";
import MoreTimeOutlinedIcon from "@mui/icons-material/MoreTimeOutlined";
import { Course } from "@/types/course";
import { Autocomplete, MenuItem, Snackbar, Stack } from "@mui/material";
import { CourseOfferingWithoutId } from "@/types/courseOffering";
import { getTeacherList } from "@/api/teacherAPI";
import { Teacher } from "@/types/teacher";
import { Semester, semesterList } from "@/types/semester.d";

interface Props {
  course: Course;
  onOpen: (courseOffering: CourseOfferingWithoutId) => Promise<boolean>;
  onOpenSuccess?: () => void;
}

const ButtonForOpen: React.FC<Props> = memo(
  ({
    course,
    onOpen: handleOpen,
    onOpenSuccess: handleUOpenSuccess = () => {},
  }) => {
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [isSnackbarOpen, setIsSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState("");
    const [semester, setSemester] = useState<Semester>("");
    const [teacherList, setTeacherList] = useState<Teacher[]>([]);
    const [teacherSelected, setTeacherSelected] = useState<string | null>(null);

    const fetchTeacherList = async () => {
      setTeacherList(await getTeacherList());
    };

    useEffect(() => {
      fetchTeacherList();
    }, []);

    const handleClickOpen = () => {
      setIsDialogOpen(true);
    };

    const handleClose = () => {
      setIsDialogOpen(false);
    };

    const onSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      const formData = new FormData(event.currentTarget);
      const formJson = Object.fromEntries((formData as any).entries());
      const courseOffering: CourseOfferingWithoutId = {
        courseId: course.id,
        teacherId: (
          (teacherSelected as string).match(
            /(?<=\()(.+?)(?=\))/g
          ) as RegExpMatchArray
        )[0],
        place: formJson.place,
        semester: semester,
        startWeek: formJson.startWeek,
        endWeek: formJson.endWeek,
        startPeriod: formJson.startPeriod,
        endPeriod: formJson.endPeriod,
      };
      if (await handleOpen(courseOffering)) {
        setSnackbarMessage("课程开设成功！");
        setIsSnackbarOpen(true);
        handleClose();
        handleUOpenSuccess();
      } else {
        setSnackbarMessage("课程开设失败！");
        setIsSnackbarOpen(true);
      }
    };

    return (
      <Fragment>
        <Button
          startIcon={<MoreTimeOutlinedIcon />}
          onClick={handleClickOpen}
          color="success"
        >
          开设
        </Button>
        <Dialog
          open={isDialogOpen}
          onClose={handleClose}
          PaperProps={{
            component: "form",
            onSubmit: onSubmit,
          }}
        >
          <DialogTitle>开设课程</DialogTitle>
          <DialogContent>
            <TextField
              disabled
              margin="dense"
              id="course_code"
              name="course_code"
              label="课程代码"
              type="text"
              fullWidth
              variant="standard"
              value={course.id}
            />
            <TextField
              disabled
              margin="dense"
              id="course_name"
              name="course_name"
              label="课程名称"
              type="text"
              fullWidth
              variant="standard"
              value={course.name}
            />
            <Autocomplete
              id="teacher"
              options={teacherList.map(
                (teacherData: Teacher): string =>
                  teacherData.name + "(" + teacherData.id + ")"
              )}
              sx={{ width: 300 }}
              renderInput={(params) => (
                <TextField
                  required
                  {...params}
                  label="上课老师"
                  type="text"
                  variant="filled"
                  autoFocus
                />
              )}
              value={teacherSelected}
              onChange={(_: any, newValue: string | null) => {
                setTeacherSelected(newValue);
              }}
            />
            <TextField
              autoFocus
              required
              margin="dense"
              id="place"
              name="place"
              label="上课地点"
              type="text"
              fullWidth
              variant="filled"
            />
            <TextField
              select
              required
              id="semester"
              name="semester"
              label="学年学期"
              value={semester}
              onChange={(e) => setSemester(e.target.value as Semester)}
              sx={{ minWidth: 150 }}
              variant="filled"
            >
              {semesterList.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </TextField>
            <Stack direction="row" justifyContent="space-between">
              <TextField
                autoFocus
                required
                margin="dense"
                id="startWeek"
                name="startWeek"
                label="开课周数"
                type="number"
                variant="filled"
                InputLabelProps={{
                  shrink: true,
                }}
              />
              <TextField
                autoFocus
                required
                margin="dense"
                id="endWeek"
                name="endWeek"
                label="结课周数"
                type="number"
                variant="filled"
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Stack>
            <Stack direction="row" justifyContent="space-between">
              <TextField
                autoFocus
                required
                margin="dense"
                id="startPeriod"
                name="startPeriod"
                label="开始节数"
                type="number"
                variant="filled"
                InputLabelProps={{
                  shrink: true,
                }}
              />
              <TextField
                autoFocus
                required
                margin="dense"
                id="endPeriod"
                name="endPeriod"
                label="结束节数"
                type="number"
                variant="filled"
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Stack>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>取消</Button>
            <Button type="submit">确定</Button>
          </DialogActions>
        </Dialog>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={4000}
          onClose={() => setIsSnackbarOpen(false)}
          message={snackbarMessage}
        />
      </Fragment>
    );
  }
);

export default ButtonForOpen;
