import Card from "@mui/material/Card";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import TabContext from "@mui/lab/TabContext";
import { useState } from "react";
import TabOptional from "./tab-selected";
import TabSelected from "./tab-optional";
import { Box } from "@mui/material";
import { Tab, TabName } from "@/components/tab";

const Register: React.FC = () => {
  const [value, setValue] = useState<string>("optional");

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  return (
    <Card>
      <TabContext value={value}>
        <TabList
          onChange={handleChange}
          aria-label="register tabs"
          textColor="secondary"
          indicatorColor="secondary"
          sx={{ borderBottom: (theme) => `1px solid ${theme.palette.divider}` }}
        >
          <Tab
            value="optional"
            label={
              <Box sx={{ display: "flex", alignItems: "center" }}>
                <TabName>备选课程</TabName>
              </Box>
            }
          />
          <Tab
            value="selected"
            label={
              <Box sx={{ display: "flex", alignItems: "center" }}>
                <TabName>已选课程</TabName>
              </Box>
            }
          />
        </TabList>

        <TabPanel sx={{ p: 0 }} value="optional">
          <TabSelected />
        </TabPanel>
        <TabPanel sx={{ p: 0 }} value="selected">
          <TabOptional />
        </TabPanel>
      </TabContext>
    </Card>
  );
};

export default Register;
