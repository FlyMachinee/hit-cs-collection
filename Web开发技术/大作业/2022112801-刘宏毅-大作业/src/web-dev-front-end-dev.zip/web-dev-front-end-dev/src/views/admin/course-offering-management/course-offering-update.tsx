/* eslint-disable @typescript-eslint/no-explicit-any */
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import { Fragment, memo, useState } from "react";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import { MenuItem, Snackbar, Stack } from "@mui/material";
import { CourseOfferingAlterable } from "@/types/courseOffering";
import { Semester, semesterList } from "@/types/semester.d";
import { CourseOfferingData } from "./types";

interface Props {
  offering: CourseOfferingData;
  onUpdate: (offering: CourseOfferingAlterable) => Promise<boolean>;
  onUpdateSuccess?: () => void;
  onUpdateFailed?: () => void;
}

const ButtonForUpdate: React.FC<Props> = memo(
  ({
    offering,
    onUpdate: handleUpdate,
    onUpdateSuccess: handleUpdateSuccess = () => {},
    onUpdateFailed: handleUpdateFailed = () => {},
  }) => {
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [isSnackbarOpen, setIsSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState("");
    const [semester, setSemester] = useState<Semester>(offering.semester);

    const handleClickOpen = () => {
      setIsDialogOpen(true);
    };

    const handleClose = () => {
      setIsDialogOpen(false);
    };

    const onSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      const formData = new FormData(event.currentTarget);
      const formJson = Object.fromEntries((formData as any).entries());
      const newOffering: CourseOfferingAlterable = {
        id: offering.id,
        place: formJson.place,
        semester: semester,
        startWeek: formJson.startWeek,
        endWeek: formJson.endWeek,
        startPeriod: formJson.startPeriod,
        endPeriod: formJson.endPeriod,
      };
      if (await handleUpdate(newOffering)) {
        setSnackbarMessage("课程安排修改成功！");
        setIsSnackbarOpen(true);
        handleClose();
        handleUpdateSuccess();
      } else {
        setSnackbarMessage("课程安排修改失败！");
        setIsSnackbarOpen(true);
        handleUpdateFailed();
      }
    };

    return (
      <Fragment>
        <Button startIcon={<SettingsOutlinedIcon />} onClick={handleClickOpen}>
          修改
        </Button>
        <Dialog
          open={isDialogOpen}
          onClose={handleClose}
          PaperProps={{
            component: "form",
            onSubmit: onSubmit,
          }}
        >
          <DialogTitle>修改课程开课信息</DialogTitle>
          <DialogContent>
            <TextField
              disabled
              autoFocus
              required
              margin="dense"
              id="course_name"
              name="course_name"
              label="课程"
              type="text"
              fullWidth
              variant="filled"
              defaultValue={offering.courseName}
            />
            <TextField
              disabled
              autoFocus
              required
              margin="dense"
              id="teacher_name"
              name="teacher_name"
              label="老师"
              type="text"
              fullWidth
              variant="filled"
              defaultValue={offering.teacherName}
            />
            <TextField
              autoFocus
              required
              margin="dense"
              id="place"
              name="place"
              label="上课地点"
              type="text"
              fullWidth
              variant="filled"
              defaultValue={offering.place}
            />
            <TextField
              select
              required
              id="semester"
              name="semester"
              label="学年学期"
              value={semester}
              onChange={(e) => setSemester(e.target.value as Semester)}
              sx={{ minWidth: 150 }}
              variant="filled"
            >
              {semesterList.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </TextField>
            <Stack direction="row" justifyContent="space-between">
              <TextField
                autoFocus
                required
                margin="dense"
                id="startWeek"
                name="startWeek"
                label="开课周数"
                type="number"
                variant="filled"
                InputLabelProps={{
                  shrink: true,
                }}
                defaultValue={offering.startWeek}
              />
              <TextField
                autoFocus
                required
                margin="dense"
                id="endWeek"
                name="endWeek"
                label="结课周数"
                type="number"
                variant="filled"
                InputLabelProps={{
                  shrink: true,
                }}
                defaultValue={offering.endWeek}
              />
            </Stack>
            <Stack direction="row" justifyContent="space-between">
              <TextField
                autoFocus
                required
                margin="dense"
                id="startPeriod"
                name="startPeriod"
                label="开始节数"
                type="number"
                variant="filled"
                InputLabelProps={{
                  shrink: true,
                }}
                defaultValue={offering.startPeriod}
              />
              <TextField
                autoFocus
                required
                margin="dense"
                id="endPeriod"
                name="endPeriod"
                label="结束节数"
                type="number"
                variant="filled"
                InputLabelProps={{
                  shrink: true,
                }}
                defaultValue={offering.endPeriod}
              />
            </Stack>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>取消</Button>
            <Button type="submit">确定</Button>
          </DialogActions>
        </Dialog>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={4000}
          onClose={() => setIsSnackbarOpen(false)}
          message={snackbarMessage}
        />
      </Fragment>
    );
  }
);

export default ButtonForUpdate;
