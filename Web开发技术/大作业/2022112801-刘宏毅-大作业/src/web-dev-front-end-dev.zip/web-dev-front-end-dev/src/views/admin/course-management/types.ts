import { Course } from "@/types/course";

export interface CourseData extends Course {
  index: number;
}

export interface TableRowType extends CourseData {
  action: React.ReactNode;
}

export interface HeadCell {
  disablePadding: boolean;
  id: keyof TableRowType;
  label: string;
  numeric: boolean;
}
