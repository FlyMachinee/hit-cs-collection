import {
  Box,
  Button,
  Checkbox,
  FormControl,
  FormControlLabel,
  FormHelperText,
  IconButton,
  InputAdornment,
  InputLabel,
  Link,
  OutlinedInput,
  Paper,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import VisibilityIconOutlined from "@mui/icons-material/VisibilityOutlined";
import VisibilityOffIconOutlined from "@mui/icons-material/VisibilityOffOutlined";
import { useNavigate } from "react-router-dom";

import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { loginAction } from "@/store/slices/user-slice";

const Login: React.FC = () => {
  const [id, setUsername] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [showPassword, setShowPassword] = useState(false);
  const [role, setRole] = useState<string>("student");
  const usernameType = role === "student" ? "学号" : "工号";

  const OKState = { isErr: false, errMsg: "" };
  const [errorState, setErrorState] = useState([OKState, OKState]);

  const navigateTo = useNavigate();
  const dispatch = useAppDispatch();
  const state = useAppSelector((state) => state.user.loginStatus);

  useEffect(() => {
    if (state === "failed") {
      setErrorState([
        { isErr: true, errMsg: usernameType + "或密码错误！" },
        { isErr: true, errMsg: usernameType + "或密码错误！" },
      ]);
    }
    if (state === "success") {
      navigateTo("/" + role);
    }
  }, [state, navigateTo, usernameType, role]);

  const onLogin = async () => {
    let isOK = true;
    const newErrorState = errorState.slice();

    // 用户名判空
    if (id === "") {
      isOK = false;
      newErrorState[0] = { isErr: true, errMsg: usernameType + "不能为空！" };
    }

    // 密码判空
    if (password === "") {
      isOK = false;
      newErrorState[1] = { isErr: true, errMsg: "密码不能为空！" };
    }

    // 只有用户名和密码都不空才发送请求
    if (isOK) {
      await dispatch(loginAction(id, password, role));
    } else {
      setErrorState(newErrorState);
    }
  };

  return (
    <Box
      sx={{
        position: "absolute",
        left: "50%",
        top: "50%",
        transform: "translate(-50%,-50%)",
      }}
    >
      <Paper
        elevation={3}
        sx={{ padding: "50px 30px 50px 30px", width: "400px" }}
      >
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 600, mb: "20px" }}>
            欢迎来到本科生教务系统！
          </Typography>
          <Typography variant="body2" sx={{ mb: 2 }}>
            请登录你的账号
          </Typography>
        </Box>
        <ToggleButtonGroup
          value={role}
          exclusive
          onChange={(_, v) => {
            setRole(v);
            setErrorState([OKState, OKState]);
          }}
          color="primary"
          fullWidth
          sx={{ mb: 2 }}
        >
          <ToggleButton value="student">学生登录</ToggleButton>
          <ToggleButton value="teacher">教师登录</ToggleButton>
          <ToggleButton value="admin">管理登录</ToggleButton>
        </ToggleButtonGroup>
        <TextField
          autoFocus
          fullWidth
          label={usernameType}
          value={id}
          onChange={(e) => {
            setUsername(e.target.value);
            setErrorState([OKState, errorState[1]]);
          }}
          error={errorState[0].isErr}
          helperText={errorState[0].errMsg}
          sx={{ mb: 2 }}
        />
        <FormControl fullWidth error={errorState[1].isErr}>
          <InputLabel>密码</InputLabel>
          <OutlinedInput
            label="密码"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              setErrorState([errorState[0], OKState]);
            }}
            type={showPassword ? "text" : "password"}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  edge="end"
                  onClick={() => setShowPassword(!showPassword)}
                  onMouseDown={(e) => e.preventDefault()}
                  aria-label="toggle password visibility"
                >
                  {showPassword ? (
                    <VisibilityIconOutlined />
                  ) : (
                    <VisibilityOffIconOutlined />
                  )}
                </IconButton>
              </InputAdornment>
            }
          />
          {errorState[1].isErr && (
            <FormHelperText>{errorState[1].errMsg}</FormHelperText>
          )}
        </FormControl>
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <FormControlLabel control={<Checkbox />} label="记住我" />
          <Link href="/">忘记密码？</Link>
        </Box>
        <Button
          fullWidth
          size="large"
          variant="contained"
          onClick={onLogin}
          sx={{ mt: 2 }}
        >
          登录
        </Button>
      </Paper>
    </Box>
  );
};

export default Login;
