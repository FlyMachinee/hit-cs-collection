/* eslint-disable @typescript-eslint/no-explicit-any */
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { Fragment, memo, useState } from "react";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import { Student } from "@/types/student";
import {
  FormControl,
  FormControlLabel,
  FormLabel,
  Radio,
  RadioGroup,
  Snackbar,
} from "@mui/material";

interface Props {
  student: Student;
  onUpdate: (oldCode: string, newStudent: Student) => Promise<0 | 1 | 2>; // 0: 正常， 1: 重复， 2：后端失败
  onUpdateSuccess?: () => void;
  onUpdateFailed?: () => void;
}

const ButtonForUpdate: React.FC<Props> = memo(
  ({
    student,
    onUpdate: handleUpdate,
    onUpdateSuccess: handleUpdateSuccess = () => {},
    onUpdateFailed: handleUpdateFailed = () => {},
  }) => {
    const oldId = student.id;
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [isSnackbarOpen, setIsSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState("");

    const [gender, setGender] = useState(student.gender);

    const handleClickOpen = () => {
      setIsDialogOpen(true);
    };

    const handleClose = () => {
      setIsDialogOpen(false);
    };

    const onSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      const formData = new FormData(event.currentTarget);
      const formJson = Object.fromEntries((formData as any).entries());
      const student: Student = {
        id: formJson.id,
        name: formJson.name,
        gender: gender,
        email: formJson.email,
        major: formJson.major,
        faculty: formJson.faculty,
      };
      switch (await handleUpdate(oldId, student)) {
        case 0: {
          setSnackbarMessage("学生修改成功！");
          setIsSnackbarOpen(true);
          handleClose();
          handleUpdateSuccess();
          break;
        }
        case 1: {
          setSnackbarMessage("修改后的学号已存在！");
          setIsSnackbarOpen(true);
          handleUpdateFailed();
          break;
        }
        case 2: {
          setSnackbarMessage("学生修改失败！");
          setIsSnackbarOpen(true);
          handleClose();
          handleUpdateFailed();
          break;
        }
      }
    };

    return (
      <Fragment>
        <Button startIcon={<SettingsOutlinedIcon />} onClick={handleClickOpen}>
          修改
        </Button>
        <Dialog
          open={isDialogOpen}
          onClose={handleClose}
          PaperProps={{
            component: "form",
            onSubmit: onSubmit,
          }}
        >
          <DialogTitle>修改学生信息</DialogTitle>
          <DialogContent>
            <DialogContentText>
              注意：修改后的学号不能与已有的重复
            </DialogContentText>
            <TextField
              autoFocus
              required
              margin="dense"
              id="id"
              name="id"
              label="学号"
              type="text"
              fullWidth
              variant="filled"
              defaultValue={student.id}
            />
            <TextField
              autoFocus
              required
              margin="dense"
              id="name"
              name="name"
              label="姓名"
              type="text"
              fullWidth
              variant="filled"
              defaultValue={student.name}
            />
            <FormControl style={{ margin: "5px" }}>
              <FormLabel id="demo-radio-buttons-group-label">性别</FormLabel>
              <RadioGroup
                row
                aria-labelledby="demo-radio-buttons-group-label"
                defaultValue="m"
                name="radio-buttons-group"
                value={gender}
                onChange={(e) => setGender(e.target.value)}
              >
                <FormControlLabel value="m" control={<Radio />} label="男" />
                <FormControlLabel value="f" control={<Radio />} label="女" />
              </RadioGroup>
            </FormControl>
            <TextField
              autoFocus
              required
              margin="dense"
              id="email"
              name="email"
              label="电子邮箱"
              type="text"
              fullWidth
              variant="filled"
              defaultValue={student.email}
            />
            <TextField
              autoFocus
              required
              margin="dense"
              id="major"
              name="major"
              label="专业"
              type="text"
              fullWidth
              variant="filled"
              defaultValue={student.major}
            />
            <TextField
              autoFocus
              required
              margin="dense"
              id="faculty"
              name="faculty"
              label="所属学院"
              type="text"
              fullWidth
              variant="filled"
              defaultValue={student.faculty}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>取消</Button>
            <Button type="submit">确定</Button>
          </DialogActions>
        </Dialog>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={4000}
          onClose={() => setIsSnackbarOpen(false)}
          message={snackbarMessage}
        />
      </Fragment>
    );
  }
);

export default ButtonForUpdate;
