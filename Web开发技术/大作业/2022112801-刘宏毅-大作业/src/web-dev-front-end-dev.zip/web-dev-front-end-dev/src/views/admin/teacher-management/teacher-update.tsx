/* eslint-disable @typescript-eslint/no-explicit-any */
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { Fragment, memo, useState } from "react";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import { Teacher } from "@/types/teacher";
import {
  FormControl,
  FormControlLabel,
  FormLabel,
  Radio,
  RadioGroup,
  Snackbar,
} from "@mui/material";

interface Props {
  teacher: Teacher;
  onUpdate: (oldCode: string, newTeacher: Teacher) => Promise<0 | 1 | 2>; // 0: 正常， 1: 重复， 2：后端失败
  onUpdateSuccess?: () => void;
  onUpdateFailed?: () => void;
}

const ButtonForUpdate: React.FC<Props> = memo(
  ({
    teacher,
    onUpdate: handleUpdate,
    onUpdateSuccess: handleUpdateSuccess = () => {},
    onUpdateFailed: handleUpdateFailed = () => {},
  }) => {
    const oldId = teacher.id;
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [isSnackbarOpen, setIsSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState("");

    const [gender, setGender] = useState(teacher.gender);

    const handleClickOpen = () => {
      setIsDialogOpen(true);
    };

    const handleClose = () => {
      setIsDialogOpen(false);
    };

    const onSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      const formData = new FormData(event.currentTarget);
      const formJson = Object.fromEntries((formData as any).entries());
      const teacher: Teacher = {
        id: formJson.id,
        name: formJson.name,
        gender: gender,
        email: formJson.email,
        title: formJson.title,
        faculty: formJson.faculty,
      };
      switch (await handleUpdate(oldId, teacher)) {
        case 0: {
          setSnackbarMessage("教师修改成功！");
          setIsSnackbarOpen(true);
          handleClose();
          handleUpdateSuccess();
          break;
        }
        case 1: {
          setSnackbarMessage("修改后的工号已存在！");
          setIsSnackbarOpen(true);
          handleUpdateFailed();
          break;
        }
        case 2: {
          setSnackbarMessage("教师修改失败！");
          setIsSnackbarOpen(true);
          handleClose();
          handleUpdateFailed();
          break;
        }
      }
    };

    return (
      <Fragment>
        <Button startIcon={<SettingsOutlinedIcon />} onClick={handleClickOpen}>
          修改
        </Button>
        <Dialog
          open={isDialogOpen}
          onClose={handleClose}
          PaperProps={{
            component: "form",
            onSubmit: onSubmit,
          }}
        >
          <DialogTitle>修改教师信息</DialogTitle>
          <DialogContent>
            <DialogContentText>
              注意：修改后的工号不能与已有的重复
            </DialogContentText>
            <TextField
              autoFocus
              required
              margin="dense"
              id="id"
              name="id"
              label="工号"
              type="text"
              fullWidth
              variant="filled"
              defaultValue={teacher.id}
            />
            <TextField
              autoFocus
              required
              margin="dense"
              id="name"
              name="name"
              label="姓名"
              type="text"
              fullWidth
              variant="filled"
              defaultValue={teacher.name}
            />
            <FormControl style={{ margin: "5px" }}>
              <FormLabel id="demo-radio-buttons-group-label">性别</FormLabel>
              <RadioGroup
                row
                aria-labelledby="demo-radio-buttons-group-label"
                defaultValue="m"
                name="radio-buttons-group"
                value={gender}
                onChange={(e) => setGender(e.target.value)}
              >
                <FormControlLabel value="m" control={<Radio />} label="男" />
                <FormControlLabel value="f" control={<Radio />} label="女" />
              </RadioGroup>
            </FormControl>
            <TextField
              autoFocus
              required
              margin="dense"
              id="email"
              name="email"
              label="电子邮箱"
              type="text"
              fullWidth
              variant="filled"
              defaultValue={teacher.email}
            />
            <TextField
              autoFocus
              required
              margin="dense"
              id="title"
              name="title"
              label="职称"
              type="text"
              fullWidth
              variant="filled"
              defaultValue={teacher.title}
            />
            <TextField
              autoFocus
              required
              margin="dense"
              id="faculty"
              name="faculty"
              label="所属学院"
              type="text"
              fullWidth
              variant="filled"
              defaultValue={teacher.faculty}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>取消</Button>
            <Button type="submit">确定</Button>
          </DialogActions>
        </Dialog>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={4000}
          onClose={() => setIsSnackbarOpen(false)}
          message={snackbarMessage}
        />
      </Fragment>
    );
  }
);

export default ButtonForUpdate;
