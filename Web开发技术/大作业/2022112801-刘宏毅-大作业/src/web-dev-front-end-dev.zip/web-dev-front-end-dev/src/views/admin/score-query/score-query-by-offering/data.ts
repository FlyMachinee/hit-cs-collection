import { HeadCell } from "./types";

export const headCells: readonly HeadCell[] = [
  {
    id: "index",
    numeric: true,
    disablePadding: true,
    label: "序号",
  },
  {
    id: "studentId",
    numeric: false,
    disablePadding: false,
    label: "学号",
  },
  {
    id: "studentName",
    numeric: false,
    disablePadding: false,
    label: "姓名",
  },
  {
    id: "studentEmail",
    numeric: false,
    disablePadding: false,
    label: "邮箱",
  },
  {
    id: "faculty",
    numeric: false,
    disablePadding: false,
    label: "所属学院",
  },
  {
    id: "score",
    numeric: true,
    disablePadding: false,
    label: "成绩",
  },
];
