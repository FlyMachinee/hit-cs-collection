import { HeadCell } from "./types";

export const headCells: readonly HeadCell[] = [
  {
    id: "id",
    numeric: true,
    disablePadding: true,
    label: "序号",
  },
  {
    id: "code",
    numeric: true,
    disablePadding: false,
    label: "课程代码",
  },
  {
    id: "name",
    numeric: false,
    disablePadding: false,
    label: "课程名称",
  },
  {
    id: "faculty",
    numeric: false,
    disablePadding: false,
    label: "开课院系",
  },
  {
    id: "credits",
    numeric: true,
    disablePadding: false,
    label: "学分",
  },
  {
    id: "score",
    numeric: true,
    disablePadding: false,
    label: "成绩",
  },
  {
    id: "gradePoint",
    numeric: true,
    disablePadding: false,
    label: "学分绩",
  },
];
