/** MUI */
import {
  Box,
  MenuItem,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  TableSortLabel,
  TextField,
  Stack,
  Button,
} from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import AddIcon from "@mui/icons-material/Add";
import { visuallyHidden } from "@mui/utils";

/** React */
import React, { useMemo, useState } from "react";

/** Types */
import { Order } from "@/types/order";
import { Data } from "../types";
import { Semester } from "@/types/semester";

/** Data */
import { headCells, semesterList } from "../data";

/** Utils */
import { getComparator, stableSort } from "@/utils/sort";

/** API */
import { getOptionalOfferingList } from "@/api/courseOfferingAPI";
import { registerCourse } from "@/api/courseRegistrationAPI";
import { useAppSelector } from "@/store/hooks";
import { selectUser } from "@/store/slices/user-slice";

interface EnhancedTableProps {
  onRequestSort: (
    event: React.MouseEvent<unknown>,
    property: keyof Data
  ) => void;
  order: Order;
  orderBy: string;
}

const EnhancedTableHead = (props: EnhancedTableProps) => {
  const { order, orderBy, onRequestSort } = props;
  const createSortHandler =
    (property: keyof Data) => (event: React.MouseEvent<unknown>) => {
      onRequestSort(event, property);
    };

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <TableCell
            key={headCell.id}
            align={headCell.numeric ? "right" : "left"}
            padding={headCell.disablePadding ? "none" : "normal"}
            sortDirection={orderBy === headCell.id ? order : false}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <Box component="span" sx={visuallyHidden}>
                  {order === "desc" ? "sorted descending" : "sorted ascending"}
                </Box>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
        <TableCell align="right">操作</TableCell>
      </TableRow>
    </TableHead>
  );
};

const TabOptional: React.FC = () => {
  const { userInfo } = useAppSelector(selectUser);
  const studentId = userInfo.id;

  const [order, setOrder] = useState<Order>("asc");
  const [orderBy, setOrderBy] = useState<keyof Data>("id");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  const [rows, setRows] = useState<Data[]>([]);
  const [courseName, setCourseName] = useState("");
  const [semester, setSemester] = useState<Semester>("");

  const updateOfferingList = async (semester: Semester, studentId: string) => {
    const offeringList = await getOptionalOfferingList(semester, studentId);
    setRows(offeringList);
  };

  const handleChangeSemester = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const { value } = e.target;
    setSemester(value as Semester);
    await updateOfferingList(value as Semester, studentId);
  };

  const handleChangeCourseName = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    setCourseName(value);
  };

  const handleQuery = async () => {
    if (courseName === "") {
      await updateOfferingList(semester, studentId);
    } else {
      setRows(rows.filter((row) => row.name.includes(courseName)));
    }
  };

  const handleRegisterCourse = async (offeringId: string) => {
    await registerCourse(studentId, offeringId);
    await updateOfferingList(semester, studentId);
  };

  const handleRequestSort = (
    event: React.MouseEvent<unknown>,
    property: keyof Data
  ) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

  const visibleRows = useMemo(
    () =>
      stableSort(rows, getComparator(order, orderBy)).slice(
        page * rowsPerPage,
        page * rowsPerPage + rowsPerPage
      ),
    [order, orderBy, page, rows, rowsPerPage]
  );

  return (
    <Box sx={{ p: 2 }}>
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        sx={{ mb: 2 }}
      >
        <Stack
          direction="row"
          justifyContent="flex-start"
          alignItems="center"
          sx={{
            "& > :not(style)": { mr: 1, width: "25ch" },
          }}
        >
          <TextField
            id="outlined-select-semester"
            required
            select
            label="学年学期"
            value={semester}
            onChange={handleChangeSemester}
          >
            {semesterList.map((option) => (
              <MenuItem key={option.value} value={option.value}>
                {option.label}
              </MenuItem>
            ))}
          </TextField>
          <TextField
            id="outlined-search"
            label="课程名称"
            type="search"
            name="course-name"
            value={courseName}
            onChange={handleChangeCourseName}
          />
        </Stack>
        <Button
          variant="contained"
          endIcon={<SendIcon />}
          onClick={handleQuery}
        >
          查询
        </Button>
      </Stack>
      <Paper sx={{ width: "100%", mb: 2 }}>
        <TableContainer>
          <Table
            sx={{ minWidth: 750 }}
            aria-labelledby="tableTitle"
            size={"medium"}
          >
            <EnhancedTableHead
              order={order}
              orderBy={orderBy}
              onRequestSort={handleRequestSort}
            />
            <TableBody>
              {visibleRows.map((row, index) => {
                const labelId = `enhanced-table-checkbox-${index}`;

                return (
                  <TableRow
                    hover
                    role="checkbox"
                    tabIndex={-1}
                    key={row.id}
                    sx={{ cursor: "pointer" }}
                  >
                    <TableCell
                      component="th"
                      id={labelId}
                      scope="row"
                      padding="none"
                      align="right"
                    >
                      {index + 1}
                    </TableCell>
                    <TableCell align="right">{row.code}</TableCell>
                    <TableCell align="left">{row.name}</TableCell>
                    <TableCell align="left">{row.info}</TableCell>
                    <TableCell align="left">{row.faculty}</TableCell>
                    <TableCell align="right">{row.credits}</TableCell>
                    <TableCell align="right">{row.hours}</TableCell>
                    <TableCell align="right">
                      <Button
                        variant="contained"
                        color="success"
                        endIcon={<AddIcon />}
                        onClick={() => handleRegisterCourse(row.id)}
                      >
                        选课
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
              {emptyRows > 0 && (
                <TableRow
                  style={{
                    height: 53 * emptyRows,
                  }}
                >
                  <TableCell colSpan={6} />
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={rows.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </Paper>
    </Box>
  );
};

export default TabOptional;
