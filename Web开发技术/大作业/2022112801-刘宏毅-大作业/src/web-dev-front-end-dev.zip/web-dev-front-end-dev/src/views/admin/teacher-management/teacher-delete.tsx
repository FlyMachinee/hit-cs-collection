import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { useState, Fragment, memo } from "react";
import DeleteIcon from "@mui/icons-material/Delete";
import { Snackbar } from "@mui/material";
import { Teacher } from "@/types/teacher";

interface Props {
  teacher: Teacher;
  onDelete: (code: string) => Promise<boolean>;
  onDeleteSuccess?: () => void;
}

const ButtonForDelete: React.FC<Props> = memo(
  ({
    teacher,
    onDelete: handleDelete,
    onDeleteSuccess: handleDeleteSuccess = () => {},
  }) => {
    const [open, setOpen] = useState<boolean>(false);
    const [isSnackbarOpen, setIsSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState("");

    const handleClickOpen = () => {
      setOpen(true);
    };

    const handleClose = () => {
      setOpen(false);
    };

    const handleConfirm = async () => {
      if (await handleDelete(teacher.id)) {
        setSnackbarMessage("教师删除成功！");
        setIsSnackbarOpen(true);
        handleDeleteSuccess();
        handleClose();
      } else {
        setSnackbarMessage("教师删除失败！");
        setIsSnackbarOpen(true);
      }
      handleClose();
    };

    return (
      <Fragment>
        <Button
          onClick={handleClickOpen}
          color="error"
          startIcon={<DeleteIcon />}
        >
          删除
        </Button>
        <Dialog
          open={open}
          onClose={handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">删除教师</DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              {`确定要删除工号为${teacher.id}的教师：“${teacher.name}”吗？`}
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>取消</Button>
            <Button onClick={handleConfirm} color="error" autoFocus>
              确定
            </Button>
          </DialogActions>
        </Dialog>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={4000}
          onClose={() => setIsSnackbarOpen(false)}
          message={snackbarMessage}
        />
      </Fragment>
    );
  }
);

export default ButtonForDelete;
