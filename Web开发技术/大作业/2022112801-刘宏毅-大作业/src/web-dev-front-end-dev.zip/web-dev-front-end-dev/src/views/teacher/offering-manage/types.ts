import { TeacherOffering } from "@/types/courseOffering";
import { Order } from "@/types/order";

export interface HeadCell {
  disablePadding: boolean;
  id: keyof TeacherOffering;
  label: string;
  numeric: boolean;
}

export interface EnhancedTableProps {
  numSelected: number;
  onRequestSort: (
    event: React.MouseEvent<unknown>,
    property: keyof TeacherOffering
  ) => void;
  onSelectAllClick: (event: React.ChangeEvent<HTMLInputElement>) => void;
  order: Order;
  orderBy: string;
  rowCount: number;
}
