import { Teacher } from "@/types/teacher";

export interface TeacherData extends Teacher {
  index: number;
}

export interface TableRowType extends TeacherData {
  action: React.ReactNode;
}

export interface HeadCell {
  disablePadding: boolean;
  id: keyof TableRowType;
  label: string;
  numeric: boolean;
}
