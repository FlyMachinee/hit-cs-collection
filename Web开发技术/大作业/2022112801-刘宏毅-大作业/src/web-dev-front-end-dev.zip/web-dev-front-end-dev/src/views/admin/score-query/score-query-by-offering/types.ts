export interface ScoreForAdmin {
  index: number;
  studentId: string;
  studentName: string;
  studentEmail: string;
  faculty: string;
  score: number;
}

export interface HeadCell {
  disablePadding: boolean;
  id: keyof ScoreForAdmin;
  label: string;
  numeric: boolean;
}
