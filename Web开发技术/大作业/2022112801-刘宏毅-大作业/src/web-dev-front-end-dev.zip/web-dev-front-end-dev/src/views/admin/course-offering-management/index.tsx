import Card from "@mui/material/Card";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import TableSortLabel from "@mui/material/TableSortLabel";
import Paper from "@mui/material/Paper";
import { visuallyHidden } from "@mui/utils";
import { Order } from "@/types/order";
import { getComparator, stableSort } from "@/utils/sort";
import { CourseOfferingData, TableRowType } from "./types";
import React, { useEffect, useMemo, useState } from "react";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import SendIcon from "@mui/icons-material/Send";
import { Box, TextField } from "@mui/material";
import { headCells } from "./data";
import { CourseOfferingAlterable } from "@/types/courseOffering";
import ButtonForDelete from "./course-offering-delete";
import ButtonForUpdate from "./course-offering-update";
import {
  deleteOfferingById,
  getOfferingList,
  updateOffering,
} from "@/api/courseOfferingAPI";

interface EnhancedTableProps {
  onRequestSort: (
    event: React.MouseEvent<unknown>,
    property: keyof TableRowType
  ) => void;
  order: Order;
  orderBy: string;
}

const EnhancedTableHead = (props: EnhancedTableProps) => {
  const { order, orderBy, onRequestSort } = props;
  const createSortHandler =
    (property: keyof TableRowType) => (event: React.MouseEvent<unknown>) => {
      onRequestSort(event, property);
    };

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) =>
          headCell.id === "id" ? (
            false
          ) : (
            <TableCell
              key={headCell.id}
              align={headCell.numeric ? "right" : "left"}
              padding={headCell.disablePadding ? "none" : "normal"}
              sortDirection={orderBy === headCell.id ? order : false}
            >
              {headCell.id === "action" ? (
                headCell.label
              ) : (
                <TableSortLabel
                  active={orderBy === headCell.id}
                  direction={orderBy === headCell.id ? order : "asc"}
                  onClick={createSortHandler(headCell.id)}
                >
                  {headCell.label}
                  {orderBy === headCell.id ? (
                    <Box component="span" sx={visuallyHidden}>
                      {order === "desc"
                        ? "sorted descending"
                        : "sorted ascending"}
                    </Box>
                  ) : null}
                </TableSortLabel>
              )}
            </TableCell>
          )
        )}
      </TableRow>
    </TableHead>
  );
};

const OfferingManagement = () => {
  const [order, setOrder] = useState<Order>("asc");
  const [orderBy, setOrderBy] = useState<keyof TableRowType>("index");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  const [rows, setRows] = useState<TableRowType[]>([]);
  const [courseName, setCourseName] = useState("");
  const [teacherName, setTeacherName] = useState("");

  const onDeleteRow = (id: string) => async () => {
    return deleteOfferingById(id);
  };

  const onUpdate = async (
    offering: CourseOfferingAlterable
  ): Promise<boolean> => {
    return await updateOffering(offering);
  };

  const getActionedOfferingList = async () => {
    const originRows: CourseOfferingData[] = await getOfferingList();
    const actionedRows: TableRowType[] = originRows.map((row) => {
      return {
        ...row,
        action: (
          <Box>
            <ButtonForUpdate
              offering={row}
              onUpdate={onUpdate}
              onUpdateSuccess={updateOfferingList}
            />
            <ButtonForDelete
              offering={row}
              onDelete={onDeleteRow(row.id)}
              onDeleteSuccess={updateOfferingList}
            />
          </Box>
        ),
      };
    });
    return actionedRows;
  };

  const updateOfferingList = async () => {
    handleQuery();
  };

  useEffect(() => {
    updateOfferingList();
  }, []);

  const handleQuery = async () => {
    const actionedRows = await getActionedOfferingList();
    const filteredRows = actionedRows.filter((row) => {
      return (
        (courseName === "" || row.courseName.includes(courseName)) &&
        (teacherName === "" || row.teacherName.includes(teacherName))
      );
    });
    setRows(filteredRows);
  };

  const handleRequestSort = (
    _: React.MouseEvent<unknown>,
    property: keyof TableRowType
  ) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleChangePage = (_: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

  const visibleRows = useMemo(
    () =>
      stableSort(rows, getComparator(order, orderBy)).slice(
        page * rowsPerPage,
        page * rowsPerPage + rowsPerPage
      ),
    [order, orderBy, page, rows, rowsPerPage]
  );

  return (
    <Card>
      <Box sx={{ p: 2 }}>
        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          sx={{ mb: 2 }}
        >
          <Stack
            direction="row"
            justifyContent="flex-start"
            alignItems="center"
            sx={{
              "& > :not(style)": { mr: 1, width: "25ch" },
            }}
          >
            <TextField
              id="outlined-search"
              label="课程名称"
              type="search"
              name="course-name"
              value={courseName}
              onChange={(e) => setCourseName(e.target.value)}
            />
            <TextField
              id="outlined-search"
              label="老师姓名"
              type="search"
              name="teacher-name"
              value={teacherName}
              onChange={(e) => setTeacherName(e.target.value)}
            />
          </Stack>
          <Box>
            <Button
              variant="contained"
              endIcon={<SendIcon />}
              onClick={handleQuery}
              sx={{ mr: 1 }}
            >
              查询
            </Button>
          </Box>
        </Stack>
        <Paper sx={{ width: "100%", mb: 2 }}>
          <TableContainer>
            <Table
              sx={{ minWidth: 750 }}
              aria-labelledby="tableTitle"
              size={"medium"}
            >
              <EnhancedTableHead
                order={order}
                orderBy={orderBy}
                onRequestSort={handleRequestSort}
              />
              <TableBody>
                {visibleRows.map((row, index) => {
                  const labelId = `enhanced-table-checkbox-${index}`;

                  return (
                    <TableRow
                      hover
                      role="checkbox"
                      tabIndex={-1}
                      key={row.id}
                      sx={{ cursor: "pointer" }}
                    >
                      <TableCell
                        component="th"
                        id={labelId}
                        scope="row"
                        padding="none"
                        align="right"
                      >
                        {row.index}
                      </TableCell>
                      <TableCell align="left">{row.courseName}</TableCell>
                      <TableCell align="left">{row.teacherName}</TableCell>
                      <TableCell align="left">{row.place}</TableCell>
                      <TableCell align="left">{row.semester}</TableCell>
                      <TableCell align="right">{row.startWeek}</TableCell>
                      <TableCell align="right">{row.endWeek}</TableCell>
                      <TableCell align="right">{row.startPeriod}</TableCell>
                      <TableCell align="right">{row.endPeriod}</TableCell>
                      <TableCell align="right">{row.action}</TableCell>
                    </TableRow>
                  );
                })}
                {emptyRows > 0 && (
                  <TableRow
                    style={{
                      height: 53 * emptyRows,
                    }}
                  >
                    <TableCell colSpan={6} />
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={rows.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Paper>
      </Box>
    </Card>
  );
};

export default OfferingManagement;
