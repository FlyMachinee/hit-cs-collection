import { Semester } from "@/types/semester";
import { HeadCell } from "./types";

export const headCells: readonly HeadCell[] = [
  {
    id: "id",
    numeric: true,
    disablePadding: true,
    label: "序号",
  },
  {
    id: "code",
    numeric: true,
    disablePadding: false,
    label: "课程代码",
  },
  {
    id: "name",
    numeric: false,
    disablePadding: false,
    label: "课程名称",
  },
  {
    id: "info",
    numeric: false,
    disablePadding: false,
    label: "上课信息",
  },
  {
    id: "faculty",
    numeric: false,
    disablePadding: false,
    label: "开课院系",
  },
  {
    id: "credits",
    numeric: true,
    disablePadding: false,
    label: "学分",
  },
  {
    id: "hours",
    numeric: true,
    disablePadding: false,
    label: "学时",
  },
];

export const semesterList: { value: Semester; label: string }[] = [
  {
    value: "2024sp",
    label: "2024春季",
  },
  {
    value: "2023fa",
    label: "2023秋季",
  },
  {
    value: "2023su",
    label: "2023夏季",
  },
  {
    value: "2023sp",
    label: "2023春季",
  },
];
