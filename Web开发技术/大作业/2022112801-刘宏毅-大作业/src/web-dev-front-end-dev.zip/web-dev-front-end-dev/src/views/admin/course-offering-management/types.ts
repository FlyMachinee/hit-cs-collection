import { Semester } from "@/types/semester";

export interface CourseOfferingData {
  index: number;
  id: string;
  courseName: string;
  teacherName: string;
  place: string;
  semester: Semester;
  startWeek: string;
  endWeek: string;
  startPeriod: string;
  endPeriod: string;
}

export interface TableRowType extends CourseOfferingData {
  action: React.ReactNode;
}

export interface HeadCell {
  disablePadding: boolean;
  id: keyof TableRowType;
  label: string;
  numeric: boolean;
}
