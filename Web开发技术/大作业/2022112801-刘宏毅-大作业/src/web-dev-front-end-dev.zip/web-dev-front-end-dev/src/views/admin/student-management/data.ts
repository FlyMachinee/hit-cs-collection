import { HeadCell } from "./types";

export const headCells: readonly HeadCell[] = [
  {
    id: "index",
    numeric: true,
    disablePadding: true,
    label: "序号",
  },
  {
    id: "id",
    numeric: false,
    disablePadding: false,
    label: "学号",
  },
  {
    id: "name",
    numeric: false,
    disablePadding: false,
    label: "姓名",
  },
  {
    id: "gender",
    numeric: false,
    disablePadding: false,
    label: "性别",
  },
  {
    id: "email",
    numeric: false,
    disablePadding: false,
    label: "电子邮箱",
  },
  {
    id: "major",
    numeric: false,
    disablePadding: false,
    label: "专业",
  },
  {
    id: "faculty",
    numeric: false,
    disablePadding: false,
    label: "所属学院",
  },
  {
    id: "action",
    numeric: true,
    disablePadding: false,
    label: "操作",
  },
];
