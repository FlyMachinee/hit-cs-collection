import { HeadCell } from "./types";

export const headCells: readonly HeadCell[] = [
  {
    id: "index",
    numeric: true,
    disablePadding: true,
    label: "序号",
  },
  {
    id: "id",
    numeric: true,
    disablePadding: false,
    label: "uuid(你不该看到我)",
  },
  {
    id: "courseName",
    numeric: false,
    disablePadding: false,
    label: "课程",
  },
  {
    id: "teacherName",
    numeric: false,
    disablePadding: false,
    label: "教师",
  },
  {
    id: "place",
    numeric: false,
    disablePadding: false,
    label: "上课地点",
  },
  {
    id: "semester",
    numeric: false,
    disablePadding: false,
    label: "学年学期",
  },
  {
    id: "startWeek",
    numeric: true,
    disablePadding: false,
    label: "开课周数",
  },
  {
    id: "endWeek",
    numeric: true,
    disablePadding: false,
    label: "结课周数",
  },
  {
    id: "startPeriod",
    numeric: true,
    disablePadding: false,
    label: "开始节数",
  },
  {
    id: "endPeriod",
    numeric: true,
    disablePadding: false,
    label: "结束节数",
  },
  {
    id: "action",
    numeric: true,
    disablePadding: false,
    label: "操作",
  },
];
