/* eslint-disable @typescript-eslint/no-explicit-any */
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { Fragment, memo, useState } from "react";
import AddIcon from "@mui/icons-material/Add";
import { Student } from "@/types/student";
import {
  FormControl,
  FormControlLabel,
  FormLabel,
  Radio,
  RadioGroup,
  Snackbar,
} from "@mui/material";

interface Props {
  onCreate: (student: Student) => Promise<boolean>;
  onCreateSuccess?: () => void;
  onCreateFailed?: () => void;
}

const ButtonForCreate: React.FC<Props> = memo(
  ({
    onCreate: handleCreate,
    onCreateSuccess: handleCreateSuccess = () => {},
    onCreateFailed: handleCreateFailed = () => {},
  }) => {
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [isSnackbarOpen, setIsSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState("");

    const [gender, setGender] = useState("m");

    const handleClickOpen = () => {
      setIsDialogOpen(true);
    };

    const handleClose = () => {
      setIsDialogOpen(false);
    };

    const onSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      const formData = new FormData(event.currentTarget);
      const formJson = Object.fromEntries((formData as any).entries());
      const student: Student = {
        id: formJson.id,
        name: formJson.name,
        gender: gender,
        email: formJson.email,
        major: formJson.major,
        faculty: formJson.faculty,
      };
      if (await handleCreate(student)) {
        setSnackbarMessage("学生添加成功！");
        setIsSnackbarOpen(true);
        handleClose();
        handleCreateSuccess();
      } else {
        setSnackbarMessage("该学号已存在！");
        setIsSnackbarOpen(true);
        handleCreateFailed();
      }
    };

    return (
      <Fragment>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={handleClickOpen}
        >
          添加学生
        </Button>
        <Dialog
          open={isDialogOpen}
          onClose={handleClose}
          PaperProps={{
            component: "form",
            onSubmit: onSubmit,
          }}
        >
          <DialogTitle>添加学生</DialogTitle>
          <DialogContent>
            <DialogContentText>
              注意：新增学生的学号不能与已有的重复
            </DialogContentText>
            <TextField
              autoFocus
              required
              margin="dense"
              id="id"
              name="id"
              label="学号"
              type="text"
              fullWidth
              variant="filled"
            />
            <TextField
              autoFocus
              required
              margin="dense"
              id="name"
              name="name"
              label="姓名"
              type="text"
              fullWidth
              variant="filled"
            />
            <FormControl style={{ margin: "5px" }}>
              <FormLabel id="demo-radio-buttons-group-label">性别</FormLabel>
              <RadioGroup
                row
                aria-labelledby="demo-radio-buttons-group-label"
                defaultValue="m"
                name="radio-buttons-group"
                value={gender}
                onChange={(e) => setGender(e.target.value)}
              >
                <FormControlLabel value="m" control={<Radio />} label="男" />
                <FormControlLabel value="f" control={<Radio />} label="女" />
              </RadioGroup>
            </FormControl>
            <TextField
              autoFocus
              required
              margin="dense"
              id="email"
              name="email"
              label="电子邮箱"
              type="text"
              fullWidth
              variant="filled"
            />
            <TextField
              autoFocus
              required
              margin="dense"
              id="major"
              name="major"
              label="专业"
              type="text"
              fullWidth
              variant="filled"
            />
            <TextField
              autoFocus
              required
              margin="dense"
              id="faculty"
              name="faculty"
              label="所属学院"
              type="text"
              fullWidth
              variant="filled"
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>取消</Button>
            <Button type="submit">确定</Button>
          </DialogActions>
        </Dialog>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={4000}
          onClose={() => setIsSnackbarOpen(false)}
          message={snackbarMessage}
        />
      </Fragment>
    );
  }
);

export default ButtonForCreate;
