import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { selectUser, updateUserInfoAction } from "@/store/slices/user-slice";
import { Button, CardContent, Grid, TextField } from "@mui/material";
import { useState } from "react";

const TabInfo: React.FC = () => {
  const { userInfo } = useAppSelector(selectUser);
  const dispatch = useAppDispatch();
  const [email, setEmail] = useState<string>(userInfo.email);

  const handleEmailChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(event.target.value);
  };

  const onSave = () => {
    dispatch(updateUserInfoAction({ ...userInfo, email: email }));
  };

  return (
    <CardContent>
      <Grid container spacing={7}>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            disabled
            label="姓名"
            defaultValue={userInfo.name}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            disabled
            label="性别"
            defaultValue={userInfo.gender}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            disabled
            label={userInfo.role === "student" ? "学号" : "工号"}
            defaultValue={userInfo.id}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            disabled
            label="角色"
            defaultValue={
              userInfo.role === "student"
                ? "学生"
                : userInfo.role === "teacher"
                ? "教师"
                : userInfo.role === "admin"
                ? "管理员"
                : "未知"
            }
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="邮箱"
            value={email}
            onChange={handleEmailChange}
          />
        </Grid>
        {userInfo.role === "teacher" && (
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              disabled
              label="职称"
              defaultValue={userInfo.title}
            />
          </Grid>
        )}
        {userInfo.role !== "admin" && (
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              disabled
              label="学院"
              defaultValue={userInfo.faculty}
            />
          </Grid>
        )}
        <Grid item xs={12}>
          <Button onClick={onSave} variant="contained">
            保存修改
          </Button>
        </Grid>
      </Grid>
    </CardContent>
  );
};

export default TabInfo;
