/** MUI */
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  TableSortLabel,
  TextField,
  Card,
  Fab,
  Paper,
} from "@mui/material";
import { visuallyHidden } from "@mui/utils";

/** React */
import React, { useCallback, useEffect, useMemo, useState } from "react";

/** Types */
import { Order } from "@/types/order";

/** Data */
import { headCells } from "./data";

/** Utils */
import { getComparator, stableSort } from "@/utils/sort";

/** API */
import { ScoreForTeacher } from "@/types/courseRegistration";
import { getScoreForTeacher, registerScore } from "@/api/courseRegistrationAPI";
import { useParams } from "react-router-dom";

interface EnhancedTableProps {
  onRequestSort: (
    event: React.MouseEvent<unknown>,
    property: keyof ScoreForTeacher
  ) => void;
  order: Order;
  orderBy: string;
}

const EnhancedTableHead = (props: EnhancedTableProps) => {
  const { order, orderBy, onRequestSort } = props;
  const createSortHandler =
    (property: keyof ScoreForTeacher) => (event: React.MouseEvent<unknown>) => {
      onRequestSort(event, property);
    };

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <TableCell
            key={headCell.id}
            align={headCell.numeric ? "right" : "left"}
            padding={headCell.disablePadding ? "none" : "normal"}
            sortDirection={orderBy === headCell.id ? order : false}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <Box component="span" sx={visuallyHidden}>
                  {order === "desc" ? "sorted descending" : "sorted ascending"}
                </Box>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
};

const ScoreManagement: React.FC = () => {
  const [order, setOrder] = useState<Order>("asc");
  const [orderBy, setOrderBy] = useState<keyof ScoreForTeacher>("id");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  const [rows, setRows] = useState<ScoreForTeacher[]>([]);

  const params = useParams();

  const handleRequestSort = (
    event: React.MouseEvent<unknown>,
    property: keyof ScoreForTeacher
  ) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleScoreChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    // 获取输入框的名称，这里假设名称是 'studentId'，并且是唯一的
    const { name, value } = event.target;
    // 获取新的分数值
    const newScore = parseFloat(value) || 0;

    // 使用状态更新函数来更新rows数组
    setRows((prevRows) => {
      // 拷贝当前rows数组
      const updatedRows = [...prevRows];

      // 找到对应的学生并更新分数
      const index = updatedRows.findIndex((row) => row.studentId === name);
      if (index !== -1) {
        updatedRows[index].score = newScore;
      }

      // 返回更新后的rows数组
      return updatedRows;
    });
  };

  const handleRegisterScore = async () => {
    await registerScore(rows);
  };

  useEffect(() => {
    const updateRows = async () => {
      const data = await getScoreForTeacher(params.id as string);
      setRows(data);
    };
    updateRows();
  }, [params.id]);

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

  const visibleRows = useMemo(
    () =>
      stableSort(rows, getComparator(order, orderBy)).slice(
        page * rowsPerPage,
        page * rowsPerPage + rowsPerPage
      ),
    [order, orderBy, page, rows, rowsPerPage]
  );

  return (
    <Card sx={{ p: 2 }}>
      <Paper sx={{ width: "100%", mb: 2 }}>
        <TableContainer>
          <Table
            sx={{ minWidth: 750 }}
            aria-labelledby="tableTitle"
            size={"medium"}
          >
            <EnhancedTableHead
              order={order}
              orderBy={orderBy}
              onRequestSort={handleRequestSort}
            />
            <TableBody>
              {visibleRows.map((row, index) => {
                const labelId = `enhanced-table-checkbox-${index}`;

                return (
                  <TableRow
                    hover
                    role="checkbox"
                    tabIndex={-1}
                    key={row.id}
                    sx={{ cursor: "pointer" }}
                  >
                    <TableCell
                      component="th"
                      id={labelId}
                      scope="row"
                      padding="none"
                      align="right"
                    >
                      {index + 1}
                    </TableCell>
                    <TableCell align="right">{row.studentId}</TableCell>
                    <TableCell align="left">{row.studentName}</TableCell>
                    <TableCell align="right">{row.studentEmail}</TableCell>
                    <TableCell align="left">{row.faculty}</TableCell>
                    <TableCell align="right">
                      <TextField
                        id="filled-number"
                        type="number"
                        variant="filled"
                        name={row.studentId}
                        value={row.score === null ? "" : row.score}
                        onChange={handleScoreChange}
                      />
                    </TableCell>
                  </TableRow>
                );
              })}
              {emptyRows > 0 && (
                <TableRow
                  style={{
                    height: 53 * emptyRows,
                  }}
                >
                  <TableCell colSpan={6} />
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={rows.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </Paper>
      <Fab color="success" onClick={handleRegisterScore}>
        录入
      </Fab>
    </Card>
  );
};

export default ScoreManagement;
