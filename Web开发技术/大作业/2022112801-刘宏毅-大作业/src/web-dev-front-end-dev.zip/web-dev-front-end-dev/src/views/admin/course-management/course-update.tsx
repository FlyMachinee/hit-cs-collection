/* eslint-disable @typescript-eslint/no-explicit-any */
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { Fragment, memo, useState } from "react";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import { Course } from "@/types/course";
import { Snackbar } from "@mui/material";

interface Props {
  course: Course;
  onUpdate: (oldCode: string, newCourse: Course) => Promise<0 | 1 | 2>; // 0: 正常， 1: 重复， 2：后端失败
  onUpdateSuccess?: () => void;
  onUpdateFailed?: () => void;
}

const ButtonForUpdate: React.FC<Props> = memo(
  ({
    course,
    onUpdate: handleUpdate,
    onUpdateSuccess: handleUpdateSuccess = () => {},
    onUpdateFailed: handleUpdateFailed = () => {},
  }) => {
    const oldCode = course.id;
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [isSnackbarOpen, setIsSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState("");

    const handleClickOpen = () => {
      setIsDialogOpen(true);
    };

    const handleClose = () => {
      setIsDialogOpen(false);
    };

    const onSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      const formData = new FormData(event.currentTarget);
      const formJson = Object.fromEntries((formData as any).entries());
      const course: Course = {
        id: formJson.code,
        name: formJson.name,
        credits: formJson.credits,
        description: formJson.description,
      };
      switch (await handleUpdate(oldCode, course)) {
        case 0: {
          setSnackbarMessage("课程修改成功！");
          setIsSnackbarOpen(true);
          handleClose();
          handleUpdateSuccess();
          break;
        }
        case 1: {
          setSnackbarMessage("修改后的课程代号已存在！");
          setIsSnackbarOpen(true);
          handleUpdateFailed();
          break;
        }
        case 2: {
          setSnackbarMessage("课程修改失败！");
          setIsSnackbarOpen(true);
          handleClose();
          handleUpdateFailed();
          break;
        }
      }
    };

    return (
      <Fragment>
        <Button startIcon={<SettingsOutlinedIcon />} onClick={handleClickOpen}>
          修改
        </Button>
        <Dialog
          open={isDialogOpen}
          onClose={handleClose}
          PaperProps={{
            component: "form",
            onSubmit: onSubmit,
          }}
        >
          <DialogTitle>修改课程信息</DialogTitle>
          <DialogContent>
            <DialogContentText>
              注意：修改后的课程代码不能与已有的重复。
            </DialogContentText>
            <TextField
              autoFocus
              required
              margin="dense"
              id="code"
              name="code"
              label="课程代码"
              type="text"
              fullWidth
              variant="filled"
              defaultValue={course.id}
            />
            <TextField
              autoFocus
              required
              margin="dense"
              id="name"
              name="name"
              label="课程名称"
              type="text"
              fullWidth
              variant="filled"
              defaultValue={course.name}
            />
            <TextField
              autoFocus
              required
              margin="dense"
              id="credits"
              name="credits"
              label="学分"
              type="number"
              inputProps={{ step: 0.5 }}
              fullWidth
              variant="filled"
              defaultValue={course.credits}
            />
            <TextField
              autoFocus
              required
              margin="dense"
              id="description"
              name="description"
              label="课程信息"
              type="text"
              fullWidth
              variant="filled"
              placeholder={'留空为"无"'}
              InputLabelProps={{
                shrink: true,
              }}
              defaultValue={course.description}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>取消</Button>
            <Button type="submit">确定</Button>
          </DialogActions>
        </Dialog>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={4000}
          onClose={() => setIsSnackbarOpen(false)}
          message={snackbarMessage}
        />
      </Fragment>
    );
  }
);

export default ButtonForUpdate;
