import { Student } from "@/types/student";

export interface StudentData extends Student {
  index: number;
}

export interface TableRowType extends StudentData {
  action: React.ReactNode;
}

export interface HeadCell {
  disablePadding: boolean;
  id: keyof TableRowType;
  label: string;
  numeric: boolean;
}
