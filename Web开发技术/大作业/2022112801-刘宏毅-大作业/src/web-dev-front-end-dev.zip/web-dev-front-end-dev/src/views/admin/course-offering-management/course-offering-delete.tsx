import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { useState, Fragment, memo } from "react";
import DeleteIcon from "@mui/icons-material/Delete";
import { Snackbar } from "@mui/material";
import { CourseOfferingData } from "./types";

interface Props {
  offering: CourseOfferingData;
  onDelete: (id: string) => Promise<boolean>;
  onDeleteSuccess?: () => void;
}

const ButtonForDelete: React.FC<Props> = memo(
  ({
    offering,
    onDelete: handleDelete,
    onDeleteSuccess: handleDeleteSuccess = () => {},
  }) => {
    const [open, setOpen] = useState<boolean>(false);
    const [isSnackbarOpen, setIsSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState("");

    const handleClickOpen = () => {
      setOpen(true);
    };

    const handleClose = () => {
      setOpen(false);
    };

    const handleConfirm = async () => {
      if (await handleDelete(offering.id)) {
        setSnackbarMessage("课程安排删除成功！");
        setIsSnackbarOpen(true);
        handleDeleteSuccess();
        handleClose();
      } else {
        setSnackbarMessage("课程安排删除失败！");
        setIsSnackbarOpen(true);
      }
      handleClose();
    };

    return (
      <Fragment>
        <Button
          onClick={handleClickOpen}
          color="error"
          startIcon={<DeleteIcon />}
        >
          删除
        </Button>
        <Dialog
          open={open}
          onClose={handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">删除课程</DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              {`确定要删除课程“${offering.courseName}”的课程安排吗？`}
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>取消</Button>
            <Button onClick={handleConfirm} color="error" autoFocus>
              确定
            </Button>
          </DialogActions>
        </Dialog>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={4000}
          onClose={() => setIsSnackbarOpen(false)}
          message={snackbarMessage}
        />
      </Fragment>
    );
  }
);

export default ButtonForDelete;
