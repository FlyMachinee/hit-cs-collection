/** MUI */
import {
  Box,
  Button,
  CardContent,
  FormControl,
  Grid,
  IconButton,
  InputAdornment,
  InputLabel,
  OutlinedInput,
} from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";

/** React */
import { ChangeEvent, MouseEvent, useState } from "react";
import { selectUser, updateUserInfoAction } from "@/store/slices/user-slice";
import { useAppDispatch, useAppSelector } from "@/store/hooks";

interface State {
  newPassword: string;
  currentPassword: string;
  showNewPassword: boolean;
  confirmNewPassword: string;
  showCurrentPassword: boolean;
  showConfirmNewPassword: boolean;
}

const TabSecurity = () => {
  const { userInfo } = useAppSelector(selectUser);
  const dispatch = useAppDispatch();

  const [values, setValues] = useState<State>({
    newPassword: "",
    currentPassword: "",
    showNewPassword: false,
    confirmNewPassword: "",
    showCurrentPassword: false,
    showConfirmNewPassword: false,
  });

  // Handle Current Password
  const handleCurrentPasswordChange =
    (prop: keyof State) => (event: ChangeEvent<HTMLInputElement>) => {
      setValues({ ...values, [prop]: event.target.value });
    };
  const handleClickShowCurrentPassword = () => {
    setValues({ ...values, showCurrentPassword: !values.showCurrentPassword });
  };
  const handleMouseDownCurrentPassword = (
    event: MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };

  // Handle New Password
  const handleNewPasswordChange =
    (prop: keyof State) => (event: ChangeEvent<HTMLInputElement>) => {
      setValues({ ...values, [prop]: event.target.value });
    };
  const handleClickShowNewPassword = () => {
    setValues({ ...values, showNewPassword: !values.showNewPassword });
  };
  const handleMouseDownNewPassword = (event: MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
  };

  // Handle Confirm New Password
  const handleConfirmNewPasswordChange =
    (prop: keyof State) => (event: ChangeEvent<HTMLInputElement>) => {
      setValues({ ...values, [prop]: event.target.value });
    };
  const handleClickShowConfirmNewPassword = () => {
    setValues({
      ...values,
      showConfirmNewPassword: !values.showConfirmNewPassword,
    });
  };
  const handleMouseDownConfirmNewPassword = (
    event: MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };

  const onSave = () => {
    if (
      values.newPassword === values.confirmNewPassword &&
      values.currentPassword === userInfo.password
    ) {
      dispatch(
        updateUserInfoAction({ ...userInfo, password: values.newPassword })
      );
    }
  };

  return (
    <CardContent sx={{ pb: 0 }}>
      <Grid container spacing={7}>
        <Grid item xs={12} sm={6}>
          <Grid container spacing={7}>
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel htmlFor="account-settings-current-password">
                  当前密码
                </InputLabel>
                <OutlinedInput
                  label="当前密码"
                  value={values.currentPassword}
                  id="account-settings-current-password"
                  type={values.showCurrentPassword ? "text" : "password"}
                  onChange={handleCurrentPasswordChange("currentPassword")}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        edge="end"
                        aria-label="toggle password visibility"
                        onClick={handleClickShowCurrentPassword}
                        onMouseDown={handleMouseDownCurrentPassword}
                      >
                        {values.showCurrentPassword ? (
                          <VisibilityIcon />
                        ) : (
                          <VisibilityOffIcon />
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                />
              </FormControl>
            </Grid>

            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel htmlFor="account-settings-new-password">
                  修改密码
                </InputLabel>
                <OutlinedInput
                  label="修改密码"
                  value={values.newPassword}
                  id="account-settings-new-password"
                  onChange={handleNewPasswordChange("newPassword")}
                  type={values.showNewPassword ? "text" : "password"}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        edge="end"
                        onClick={handleClickShowNewPassword}
                        aria-label="toggle password visibility"
                        onMouseDown={handleMouseDownNewPassword}
                      >
                        {values.showNewPassword ? (
                          <VisibilityIcon />
                        ) : (
                          <VisibilityOffIcon />
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                />
              </FormControl>
            </Grid>

            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel htmlFor="account-settings-confirm-new-password">
                  确认密码
                </InputLabel>
                <OutlinedInput
                  label="确认密码"
                  value={values.confirmNewPassword}
                  id="account-settings-confirm-new-password"
                  type={values.showConfirmNewPassword ? "text" : "password"}
                  onChange={handleConfirmNewPasswordChange(
                    "confirmNewPassword"
                  )}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        edge="end"
                        aria-label="toggle password visibility"
                        onClick={handleClickShowConfirmNewPassword}
                        onMouseDown={handleMouseDownConfirmNewPassword}
                      >
                        {values.showConfirmNewPassword ? (
                          <VisibilityIcon />
                        ) : (
                          <VisibilityOffIcon />
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                />
              </FormControl>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <Box sx={{ mt: 7 }}>
        <Button variant="contained" sx={{ mr: 3.5 }} onClick={onSave}>
          保存修改
        </Button>
        <Button
          type="reset"
          variant="outlined"
          color="secondary"
          onClick={() =>
            setValues({
              ...values,
              currentPassword: "",
              newPassword: "",
              confirmNewPassword: "",
            })
          }
        >
          重置
        </Button>
      </Box>
    </CardContent>
  );
};
export default TabSecurity;
