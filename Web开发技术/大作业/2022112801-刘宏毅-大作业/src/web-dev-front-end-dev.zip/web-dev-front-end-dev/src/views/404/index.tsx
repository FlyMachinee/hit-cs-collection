import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { logoutAction, selectUser } from "@/store/slices/user-slice";
import { Box, Button, Typography } from "@mui/material";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const Error404 = () => {
  const dispatch = useAppDispatch();
  const { userInfo } = useAppSelector(selectUser);
  const navigate = useNavigate();

  useState(() => {
    if (userInfo.role === "") {
      dispatch(logoutAction);
      navigate("/login");
    } else {
      navigate("/" + userInfo.role);
    }
  });

  return (
    <Box className="content-center">
      <Box
        sx={{
          p: 5,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          textAlign: "center",
        }}
      >
        <Typography variant="h1">404</Typography>
        <Typography variant="h5" sx={{ mb: 1, fontSize: "1.5rem !important" }}>
          Page Not Found ⚠️
        </Typography>
        <Typography variant="body2">
          We couldn&prime;t find the page you are looking for.
        </Typography>
        <Button component={Link} to="/login" sx={{ px: 5.5 }}>
          Back to Home
        </Button>
      </Box>
    </Box>
  );
};

export default Error404;
