import { HeadCell } from "./types";

export const headCells: readonly HeadCell[] = [
  {
    id: "index",
    numeric: true,
    disablePadding: true,
    label: "序号",
  },
  {
    id: "id",
    numeric: true,
    disablePadding: false,
    label: "课程代码",
  },
  {
    id: "name",
    numeric: false,
    disablePadding: false,
    label: "课程名称",
  },
  {
    id: "credits",
    numeric: true,
    disablePadding: false,
    label: "学分",
  },
  {
    id: "description",
    numeric: false,
    disablePadding: false,
    label: "课程信息",
  },
  {
    id: "action",
    numeric: true,
    disablePadding: false,
    label: "操作",
  },
];
