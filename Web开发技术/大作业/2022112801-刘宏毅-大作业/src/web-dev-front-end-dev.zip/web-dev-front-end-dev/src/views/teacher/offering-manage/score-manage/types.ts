import { ScoreForTeacher } from "@/types/courseRegistration";
import { Order } from "@/types/order";

export interface HeadCell {
  disablePadding: boolean;
  id: keyof ScoreForTeacher;
  label: string;
  numeric: boolean;
}

export interface EnhancedTableProps {
  numSelected: number;
  onRequestSort: (
    event: React.MouseEvent<unknown>,
    property: keyof ScoreForTeacher
  ) => void;
  onSelectAllClick: (event: React.ChangeEvent<HTMLInputElement>) => void;
  order: Order;
  orderBy: string;
  rowCount: number;
}
