import { HeadCell } from "./types";

export const headCells: readonly HeadCell[] = [
  {
    id: "id",
    numeric: true,
    disablePadding: true,
    label: "序号",
  },
  {
    id: "studentId",
    numeric: true,
    disablePadding: false,
    label: "学号",
  },
  {
    id: "studentName",
    numeric: false,
    disablePadding: false,
    label: "姓名",
  },
  {
    id: "studentEmail",
    numeric: false,
    disablePadding: false,
    label: "邮箱",
  },
  {
    id: "faculty",
    numeric: false,
    disablePadding: false,
    label: "学院",
  },
];
