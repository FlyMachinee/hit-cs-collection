import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import type { RootStateType, DispatchType } from "..";
import { User } from "@/types/user";
import { login, updateInfo } from "@/api/userAPI";

interface UserState {
  userInfo: User;
  loginStatus: "idle" | "login" | "success" | "failed";
}

// 使用该类型定义初始 state
const initialState: UserState = {
  userInfo: {
    name: "",
    gender: "",
    id: "",
    role: "",
    email: "",
    // title: "",
    // faculty: "",
    password: "",
  },
  loginStatus: "idle",
};

export const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    loginStart: (state) => {
      state.loginStatus = "login";
    },

    loginSuccess: (state, action: PayloadAction<User>) => {
      const { name, gender, id, role, email, password } = action.payload;
      state.userInfo = {
        name: name,
        gender: gender,
        id: id,
        role: role,
        email: email,
        password: password,
      };
      if (role !== "admin") {
        state.userInfo.faculty = action.payload.faculty;
      }
      if (role === "teacher") {
        state.userInfo.title = action.payload.title;
      }
      state.loginStatus = "success";
    },

    loginFailed: (state) => {
      return { ...state, loginStatus: "failed" };
    },

    logout: () => {
      return { ...initialState };
    },

    updateUserInfo: (state, action: PayloadAction<User>) => {
      state.userInfo = action.payload;
    },
  },
});

export const { loginStart, loginSuccess, loginFailed, logout, updateUserInfo } =
  userSlice.actions;

export const loginAction =
  (id: string, password: string, role: string) =>
  async (dispatch: DispatchType) => {
    try {
      dispatch(loginStart());
      const result = await login(id, password, role);
      console.log(result);
      if (result.code === 200) {
        const { name, gender, id, role, email, password } = result.data as User;
        const userInfo: User = {
          name: name,
          gender: gender,
          id: id,
          role: role,
          email: email,
          password: password,
        };

        if (role !== "admin") {
          userInfo.faculty = result.data!.faculty;
        }
        if (role === "teacher") {
          userInfo.title = result.data!.title;
        }

        dispatch(loginSuccess(userInfo));
      } else {
        dispatch(loginFailed());
      }
    } catch (e) {
      dispatch(loginFailed());
    }
  };

export const updateUserInfoAction =
  (userInfo: User) => async (dispatch: DispatchType) => {
    const isSuccess = await updateInfo(userInfo);
    if (isSuccess) {
      dispatch(updateUserInfo(userInfo));
    }
  };

export const logoutAction = () => (dispatch: DispatchType) => {
  dispatch(logout());
};

export const selectUser = (state: RootStateType) => state.user;
export default userSlice.reducer;
