import { DrawerProps } from "@mui/material";

interface NavDrawerProps {
  isOpen: boolean;
  onClose: DrawerProps["onClose"];
}
