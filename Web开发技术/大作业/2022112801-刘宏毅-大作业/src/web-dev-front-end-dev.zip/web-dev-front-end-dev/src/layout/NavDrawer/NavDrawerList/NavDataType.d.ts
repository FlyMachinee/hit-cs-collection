interface NavDataType {
  title: string;
  herf?: string;
  children?: NavDataType[];
}

export default NavDataType;
