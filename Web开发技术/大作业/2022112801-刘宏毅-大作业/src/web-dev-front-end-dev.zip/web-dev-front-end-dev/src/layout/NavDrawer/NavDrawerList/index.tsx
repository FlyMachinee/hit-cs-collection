import { useState } from "react";
import NavDataType from "./NavDataType";
import { Collapse, List, ListItemButton, ListItemText } from "@mui/material";
import { useNavigate } from "react-router-dom";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import NavDrawerListProps from "./NavDrawerListProps";

/**
 * 根据传入的navData，返回树状导航列表
 * @param navData
 * @returns 相应的List组件
 */
const NavDrawerList: React.FC<NavDrawerListProps> = ({ navData, pl }) => {
  const [openedCollapse, setOpenedCollapse] = useState<null | string>(null);
  const navigateTo = useNavigate();

  const handleClick = (thisCollapse: string) => () => {
    setOpenedCollapse(openedCollapse === thisCollapse ? null : thisCollapse);
  };

  // 结果列表项
  const listItems: React.ReactNode[] = [];

  // 遍历navData中的每一项
  for (const navItem of navData) {
    const isLeaf = navItem.children === undefined;

    // 如果是叶节点（即导航项）
    if (isLeaf) {
      // 生成click后navigate到对应href的组件
      listItems.push(
        <ListItemButton
          onClick={() => navigateTo(navItem.herf as string)}
          sx={{ pl: pl }}
          key={navItem.herf}
        >
          <ListItemText primary={navItem.title}></ListItemText>
        </ListItemButton>
      );
    } else {
      // 否则 生成带有折叠子列表的组件
      listItems.push(
        <>
          <ListItemButton
            onClick={handleClick(navItem.title)}
            sx={{ pl: pl }}
            key={navItem.herf}
          >
            <ListItemText primary={navItem.title}></ListItemText>
            {openedCollapse === navItem.title ? (
              <ExpandLessIcon />
            ) : (
              <ExpandMoreIcon />
            )}
          </ListItemButton>
          <Collapse
            in={openedCollapse === navItem.title}
            timeout="auto"
            unmountOnExit
          >
            {/* 递归生成子列表 */}
            <NavDrawerList
              navData={navItem.children as NavDataType[]}
              pl={pl + 2 /* 给递归项一个缩进 */}
            />
          </Collapse>
        </>
      );
    }
  }

  return <List disablePadding>{listItems}</List>;
};

export default NavDrawerList;
