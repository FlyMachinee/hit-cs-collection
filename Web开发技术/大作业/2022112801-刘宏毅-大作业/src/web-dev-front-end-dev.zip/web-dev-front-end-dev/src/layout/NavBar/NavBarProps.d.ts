interface NavBarProps {
  onOpenDrawer: () => void;
}

export default NavBarProps;
