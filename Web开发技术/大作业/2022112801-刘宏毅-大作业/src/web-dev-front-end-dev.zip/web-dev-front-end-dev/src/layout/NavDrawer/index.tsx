import { Button, Drawer, Stack } from "@mui/material";
import NavDrawerList from "./NavDrawerList";
import { navData } from "./navData";
import { NavDrawerProps } from "./NavDrawerProps";
import { useAppSelector } from "@/store/hooks";
import NavDataType from "./NavDrawerList/NavDataType";
import { useNavigate } from "react-router-dom";

const NavDrawer: React.FC<NavDrawerProps> = ({ isOpen, onClose }) => {
  const { role } = useAppSelector((state) => state.user.userInfo);
  const navigate = useNavigate();

  console.log(role);
  console.log(useAppSelector((state) => state.user));
  return (
    <Drawer open={isOpen} onClose={onClose}>
      <Stack
        direction="column"
        justifyContent="space-between"
        sx={{ height: "100%" }}
      >
        <NavDrawerList navData={navData.get(role) as NavDataType[]} pl={3} />
        <Button sx={{ fontSize: 16 }} onClick={() => navigate("/settings")}>
          个人信息
        </Button>
      </Stack>
    </Drawer>
  );
};

export default NavDrawer;
