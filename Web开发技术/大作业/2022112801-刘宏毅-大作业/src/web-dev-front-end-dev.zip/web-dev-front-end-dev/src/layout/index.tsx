import { useState } from "react";
import NavBar from "./NavBar";
import { Box } from "@mui/material";
import NavDrawer from "./NavDrawer";
import { Outlet } from "react-router-dom";

const TopView: React.FC = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
      }}
    >
      <NavBar onOpenDrawer={() => setIsDrawerOpen(true)} />
      <div style={{ height: 68 }} />
      <Outlet />

      <NavDrawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} />
    </Box>
  );
};

export default TopView;
