import NavDataType from "./NavDrawerList/NavDataType";

export const navData = new Map<string, NavDataType[]>([
  [
    "admin",
    [
      {
        title: "学生管理",
        herf: "/admin/student-management",
      },
      {
        title: "教师管理",
        herf: "/admin/teacher-management",
      },
      {
        title: "课程管理",
        herf: "/admin/course-management",
      },
      {
        title: "选课管理",
        herf: "/admin/course-offering-management",
      },
      {
        title: "成绩查询",
        herf: "/admin/score-query",
      },
    ],
  ],
  [
    "student",
    [
      {
        title: "学生选课",
        herf: "/student/register",
      },
      {
        title: "成绩查询",
        herf: "/student/score-inquiry",
      },
    ],
  ],
  [
    "teacher",
    [
      {
        title: "教师登分",
        herf: "/teacher/offering-manage",
      },
    ],
  ],
]);
