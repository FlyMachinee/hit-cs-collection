import NavDataType from "./NavDataType";

interface NavDrawerListProps {
  navData: NavDataType[];
  pl: number;
}

export default NavDrawerListProps;
