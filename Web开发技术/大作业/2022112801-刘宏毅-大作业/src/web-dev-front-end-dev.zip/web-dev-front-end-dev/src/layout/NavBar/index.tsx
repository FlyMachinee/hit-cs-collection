import { AppBar, Box, IconButton, Toolbar, Typography } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import LogoutIcon from "@mui/icons-material/Logout";
import NavBarProps from "./NavBarProps";
import { useAppDispatch } from "@/store/hooks";
import { logoutAction } from "@/store/slices/user-slice";
import { useNavigate } from "react-router-dom";

const NavBar: React.FC<NavBarProps> = ({ onOpenDrawer }) => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const onLogout = async () => {
    await dispatch(logoutAction());
    navigate("/login");
  };

  return (
    <>
      <Box sx={{ flexGrow: 1 }}>
        <AppBar>
          <Toolbar>
            <IconButton
              size="large"
              edge="start"
              sx={{ mr: 2 }}
              color="inherit"
              onClick={onOpenDrawer}
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" component="div" sx={{ flexFlow: 1 }}>
              学生管理系统
            </Typography>
            <IconButton
              size="large"
              sx={{ ml: "auto" }}
              color="inherit"
              onClick={onLogout}
            >
              <LogoutIcon />
            </IconButton>
          </Toolbar>
        </AppBar>
      </Box>
    </>
  );
};

export default NavBar;
