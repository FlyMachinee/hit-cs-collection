create table course_registration
(
        id varchar primary key,
        student_id varchar references student(id),
        offering_id varchar references course_offering(id),
        score float
);