create table admin
(
        id varchar primary key,
        password varchar not null,
        name varchar not null,
        gender varchar not null,
        email varchar not null
);

insert into admin(id, password, name, gender, email) values
('admin245126751', '123456', 'admin_1', 'm', '111222333@gmail.com'),
('admin451874109', 'alpine', 'admin_2', 'f', '444555666@qq.com');