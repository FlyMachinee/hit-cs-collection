create table teacher
(
        id varchar primary key,
        password varchar not null,
        name varchar not null,
        gender varchar not null,
        email varchar not null unique,
        title varchar not null,
        faculty varchar not null
);

insert into teacher(id, password, name, gender, email, title, faculty) values
('56948514', 'wszdc', '战德臣', 'm', 'dechen@hit.edu.cn', '博士生导师 教授', '计算学部'),
('78412695', 'wsjsx', '姜守旭', 'm', 'jsx@hit.edu.cn', '博士生导师 教授', '计算学部'),
('36978452', 'wszy', '张宇', 'm', 'yuzhang517@gmail.com', '副教授', '数学学院'),
('84157416', 'wslq', '雷强', 'f', 'leiqiang@hit.edu.cn', '副教授 硕士生导师', '数学学院'),
('11203651', 'wsmch', '孟晨辉', 'f', 'mengch@hit.edu.cn', '副教授', '数学学院'),
('59846138', 'wsyt', '由田', 'f', 'youtian@hit.edu.cn', '副教授 硕士生导师', '马克思主义学院'),
('69720364', 'wslj', '李键', 'm', 'wbzd3712345@hit.edu.cn', '未知', '马克思主义学院'),
('13643762', 'wssxh', '苏小红', 'f', 'sxh@hit.edu.cn', '博士生导师', '计算学部'),
('30169024', 'wswxo', '王晓鸥', 'f', 'wxo@hit.edu.cn', '教授 博士生导师', '物理学院'),
('65491265', 'wsrsj', '任世军', 'm', 'renshijun@hit.edu.cn', '教授', '计算学部'),
('12369846', 'wszyh', '张彦航', 'f', 'wbzd12786741@hit.edu.cn', '副教授', '计算学部'),
('65349852', 'wszy', '张岩', 'm', 'zhangy@hit.edu.cn', '副教授', '计算学部'),
('45631987', 'wssxj', '史先俊', 'm', 'hitsxj@163.com', '副教授', '计算学部'),
('31295361', 'wswl', '王力', 'm', 'wangli@hit.edu.cn', '副教授', '数学学院'),
('39486571', 'wslwc', '刘文超', 'f', 'wbzd396817@hit.edu.cn', '未知', '马克思主义学院'),
('69687135', 'wsdxo', '丁小欧', 'f', 'dingxiaoou@hit.edu.cn', '硕士生导师', '计算学部'),
('65239751', 'wszz', '张展', 'm', 'zhangzhan@hit.edu.cn', '教授 博士生导师', '计算学部'),
('93564871', 'wswcy', '王春宇', 'm', 'chunyu@hit.edu.cn', '教授 博士生导师', '计算学部'),
('23697845', 'wslxm', '刘显敏', 'm', 'liuxianmin@hit.edu.cn', '副教授', '计算学部'),
('36987451', 'wsshx', '史焕翔', 'f', 'wbzd38745@hit.edu.cn', '未知', '马克思主义学院');