create table student
(
        id varchar primary key,
        password varchar not null,
        name varchar not null,
        gender varchar not null,
        email varchar not null unique,
        major varchar not null,
        faculty varchar not null
);

insert into student(id, password, name, gender, email, major, faculty) values
('2022113324', '114514', '祖甜凤', 'f', '666999444@gmail.com', '计算机科学与技术', '计算学部'),
('2021441526', '1919810', '诸游涓', 'f', '111552147@qq.com', '软件工程', '计算学部'),
('2022114514', '19200607', '霍佳群', 'm', '456987123@123.com', '人工智能', '计算学部');