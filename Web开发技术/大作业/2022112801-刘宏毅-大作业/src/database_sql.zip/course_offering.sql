create table course_offering
(
        id varchar primary key,
        course_id varchar references course(id),
        teacher_id varchar references teacher(id),
        place varchar not null,
        semester varchar not null,
        start_week integer not null,
        end_week integer not null,
        start_period integer not null,
        end_period integer not null
);

insert into course_offering(id, course_id, teacher_id, place, semester, start_week, end_week, start_period, end_period) values
('vfagtsjiyksbarh', '22MA15003', '84157416', 'B52',    '2022fa', 1, 15, 1, 2),
('batjyurksaharrg', '22MA15004', '84157416', 'BX13',   '2023sp', 1, 14, 3, 4),
('vagrvmigisjyfah', '22MA15003', '36978452', 'B51',    '2022fa', 1, 15, 1, 2),
('ihklihvccgghjkj', '22MA15004', '36978452', 'BX22',   '2023sp', 1, 14, 3, 4),
('cujjcfguicfyddj', '22MA15018', '11203651', 'B22',    '2022fa', 1, 16, 3, 4),
('dxtfjhogftdigfu', '22MX11001', '59846138', 'B414',   '2022fa', 1, 17, 5, 6),
('cgujkiugyaareiq', '22MX11003', '69720364', 'B721',   '2023sp', 1, 15, 3, 4),
('bkhgdffyjhaw4ah', '22CS21001', '13643762', 'B501',   '2022fa', 1, 14, 3, 4),
('xftoigdfxtuj4ws', '22CS21001', '12369846', 'B502',   '2022fa', 1, 14, 7, 8),
('opihyxftyjj9a2t', '22CS21002', '78412695', 'B315',   '2023sp', 1, 12, 7, 8),
('hfcfygjiyuhj74a', '22PH15003', '30169024', 'B22',    '2023sp', 1, 15, 1, 2),
('shrojgyyja67i5k', '22CS22002', '65491265', '正心524', '2023fa', 1, 9, 5, 6),
('iuygffyjkjuhygf', '22CS22003', '12369846', '正心106', '2023fa', 1, 9, 1, 2),
('fyiuuygfdftyjhq', '22CS22004', '65349852', '正心527', '2023fa', 1, 11, 3, 4),
('cfyjjluhgyfdtgh', '22CS22008', '45631987', '正心327', '2023fa', 7, 16, 1, 2),
('cfyjkugfftyiouj', '22MA15025', '31295361', '致知23',  '2023fa', 1, 13, 1, 2),
('oyfcjbhgiugyvc3', '22MX11004', '39486571', '正心31',  '2023fa', 1, 15, 1, 2),
('ygfyftoiuygfgh8', '22CS22005', '69687135', '正心527', '2024sp', 1, 8, 1, 2),
('fcxyiohugcvfyah', '22CS22006', '65239751', '致知21',  '2024sp', 1, 16, 3, 4),
('fcyogugutrdfg3t', '22CS22009', '93564871', '正心209', '2024sp', 1, 8, 5, 6),
('fyjogvcftydku3t', '22CS31000', '23697845', '正心209', '2024sp', 1, 8, 5, 6),
('uoghkbgfyukyua4', '22MX11005', '36987451', '正心34',  '2024sp', 4, 15, 3, 4),
('fygcftgfthha5uw', '22CS22013', '56948514', '正心521', '2024fa', 1, 16, 1, 2);